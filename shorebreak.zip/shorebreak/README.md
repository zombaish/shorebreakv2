# Shorebreak - Surf Forecasts for Beginners

Plain-English surf forecasts for beginner surfers. Know what the surf is doing, whether it's right for YOUR level, where to go, and what to practice next.

## Features

- **Today's Verdict** - One-glance go/no-go with plain-English reasons
- **7-Day Forecast** - Plan sessions for the week
- **Spot Finder** - Auto-generated spots from coastline data, ranked for your level
- **Skill Assessment** - 8-question quiz to determine your surf level (1-5)
- **Progress Tracker** - Checklists per level with drills and self-assessment
- **Safety Center** - Rip currents, sun safety, cold water, when to skip
- **Etiquette Guide** - Interactive rules with quiz
- **Gear Guide** - Board volume calculator, wetsuit finder, essentials checklist
- **Session Log** - Track sessions, see insights and patterns
- **Learn Center** - Glossary, FAQ, how to read forecasts
- **Alerts** - Email/push when conditions are good for your level

## Data Sources (All Free)

- **Open-Meteo Marine API** - Wave height, period, direction, swell components, water temp
- **Open-Meteo Weather API** - Wind, air temp, UV, sunrise/sunset
- **OpenStreetMap/Overpass API** - Coastline geometry for spot generation
- **Open-Meteo Geocoding** - Location search

## Scoring Engine

All calculations are pure, unit-tested functions in `src/lib/scoring/`:

- **Swell Quality (0-100)** - Period, height, swell/wind-wave ratio, direction vs coastline
- **Wind Score** - Offshore/onshore/cross-shore relative to coastline angle with speed penalties
- **Tide Suitability** - Based on level preferences
- **Beginner Suitability (1-5)** - Per level limits on height, period, wind
- **Hazard Detection** - Big period jumps, strong onshore, rip risk, cold water, low daylight, high UV
- **Confidence Rating** - Decays with forecast distance

All weights in `src/lib/scoring/config.ts` - adjust without code changes.

## Quick Start

```bash
# Install
npm install

# Develop
npm run dev

# Build for GitHub Pages
npm run build

# Preview build
npx serve out
```

## Deploy to GitHub Pages

1. Push to `main` branch
2. GitHub Actions builds and deploys automatically
3. Enable Pages in repo settings: Source = GitHub Actions
4. Site lives at `https://<username>.github.io/shorebreak/`

## Project Structure

```
src/
├── app/                    # Next.js App Router pages
│   ├── page.tsx           # Home / Today's Verdict
│   ├── forecast/          # 7-day forecast
│   ├── spots/             # Spot finder
│   ├── skill/             # Skill quiz
│   ├── progress/          # Checklists
│   ├── safety/            # Safety center
│   ├── etiquette/         # Etiquette rules
│   ├── gear/              # Gear guide
│   ├── log/               # Session log
│   ├── learn/             # Glossary, FAQ, guides
│   └── alerts/            # Notification settings
├── components/
│   ├── ui/                # Button, Card, Badge, Input, Select
│   └── layout/            # Header, Footer, Providers
├── lib/
│   ├── scoring/           # Pure scoring functions + config
│   ├── api/               # Open-Meteo, Overpass clients
│   ├── storage/           # Cache, user profile (localStorage)
│   └── utils/             # Unit conversions, formatting
├── hooks/                 # useForecast, useUser, useTheme
└── types/                 # All TypeScript interfaces
```

## Configuration

All tunable weights in `src/lib/scoring/config.ts`:

```typescript
swell: { periodWeight: 0.4, heightWeight: 0.3, ... }
wind: { offshoreBase: 100, offshoreSpeedPenalty: 2.0, ... }
beginner: [{ level: 1, maxHeightFt: 2, minPeriodSec: 8, ... }, ...]
hazards: { bigPeriodJump: { periodThresholdSec: 14, ... }, ... }
confidence: { baseConfidence: 95, decayPerDay: 8, ... }
```

## Tech Stack

- **Next.js 14** (static export for GitHub Pages)
- **React 18** + **TypeScript**
- **Tailwind CSS** (mobile-first, dark/light themes)
- **Zustand** (lightweight state)
- **SWR** (data fetching with caching)
- **Lucide React** (icons)
- **date-fns** (date formatting)

## Privacy

- No tracking, no analytics, no ads
- All data stored locally in browser (localStorage)
- Optional GitHub Pages deployment - no server needed
- Location permission only when you click "Use My Location"

## License

MIT - Free for personal and commercial use.

## Contributing

Issues and PRs welcome! Key areas:
- More hazard detection heuristics
- International tide data sources
- Offline-first PWA improvements
- Accessibility enhancements
- Translations

---

Built with ❤️ for beginner surfers everywhere. The ocean is for everyone.