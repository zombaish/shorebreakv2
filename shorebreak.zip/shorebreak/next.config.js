/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export',
  trailingSlash: true,
  images: { unoptimized: true },
  basePath: process.env.GITHUB_PAGES ? '/shorebreak' : '',
  assetPrefix: process.env.GITHUB_PAGES ? '/shorebreak/' : '',
}

module.exports = nextConfig