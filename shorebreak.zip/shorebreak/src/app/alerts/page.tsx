'use client';
import { useState, useEffect } from 'react';
import { useUser } from '@/hooks/useUser';
import { Card, CardContent, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Select } from '@/components/ui/Select';
import { Badge } from '@/components/ui/Badge';
import { Bell, BellOff, Mail, Smartphone, MapPin, Clock, Waves, Wind, Save, Loader2 } from 'lucide-react';
import { clsx } from 'clsx';

export default function AlertsPage() {
  const { profile, updateSettings } = useUser();
  const [enabled, setEnabled] = useState(profile?.settings?.notifications?.alertsEnabled || false);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<'idle'|'success'|'error'>('idle');

  const settings = profile?.settings?.notifications || {alertLevel:3,alertRadiusKm:50,alertTimeWindow:{start:'06:00',end:'10:00'},maxWindKnots:15,email:'',pushEnabled:false};

  const handleSave = async () => {
    setLoading(true);
    try {
      updateSettings({notifications:{...settings,alertsEnabled:enabled}});
      setStatus('success');
      setTimeout(()=>setStatus('idle'),3000);
    } catch { setStatus('error'); }
    setLoading(false);
  };

  if (!('Notification' in window)) {
    return (
      <div className="min-h-screen"><section className="section"><div className="container max-w-xl"><Card variant="outlined" className="border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-900/10"><CardContent className="flex items-center gap-3"><Waves className="h-5 w-5 text-amber-600"/><div><h3 className="font-medium text-amber-800 dark:text-amber-200">Push Notifications Unsupported</h3><p className="text-sm text-amber-700 dark:text-amber-300">Your browser doesn't support push notifications. Email alerts still available.</p></div></CardContent></Card></div></section></div>
    );
  }

  const requestPush = async () => {
    const perm = await Notification.requestPermission();
    if (perm === 'granted') {
      updateSettings({notifications:{...settings,pushEnabled:true}});
      setStatus('success');
    }
  };

  return (
    <div className="min-h-screen">
      <section className="section">
        <div className="container max-w-xl">
          <h1 className="page-title">Alerts</h1>
          <p className="page-subtitle">Get notified when conditions are good for your level</p>

          <Card variant="elevated" className="mb-6">
            <CardTitle className="flex items-center gap-2"><Bell className="h-5 w-5"/>Master Toggle</CardTitle>
            <CardContent>
              <label className="flex items-center justify-between cursor-pointer">
                <div><p className="font-medium">Surf Alerts</p><p className="text-sm text-slate-500">Receive notifications when conditions match your criteria</p></div>
                <input type="checkbox" checked={enabled} onChange={e=>setEnabled(e.target.checked)} className="w-5 h-5 rounded border-slate-300 text-ocean-600"/>
              </label>
            </CardContent>
          </Card>

          {enabled && (
            <>
              <Card variant="elevated" className="mb-6">
                <CardTitle>Notification Channels</CardTitle>
                <CardContent className="space-y-3">
                  <label className="flex items-center justify-between p-3 rounded-lg border border-slate-200 dark:border-slate-700"><div className="flex items-center gap-3"><Mail className="h-5 w-5 text-ocean-600"/><div><p className="font-medium">Email Alerts</p><p className="text-sm text-slate-500">Send to your inbox</p></div></div><Input type="email" placeholder="your@email.com" value={settings.email} onChange={e=>updateSettings({notifications:{...settings,email:e.target.value}})} style={{width:'200px'}}/></label>
                  <label className="flex items-center justify-between p-3 rounded-lg border border-slate-200 dark:border-slate-700"><div className="flex items-center gap-3"><Smartphone className="h-5 w-5 text-ocean-600"/><div><p className="font-medium">Push Notifications</p><p className="text-sm text-slate-500">Browser notifications</p></div></div><Button variant={settings.pushEnabled?'secondary':'outline'} size="sm" onClick={requestPush} disabled={settings.pushEnabled}>{settings.pushEnabled?'Enabled':Notification.permission==='granted'?'Enable':'Allow'}</Button></label>
                </CardContent>
              </Card>

              <Card variant="elevated" className="mb-6">
                <CardTitle>Alert Criteria</CardTitle>
                <CardContent className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <Select label="Minimum Level" value={settings.alertLevel} onChange={e=>updateSettings({notifications:{...settings,alertLevel:Number(e.target.value)}})} options={[{value:1,label:'Level 1+'},{value:2,label:'Level 2+'},{value:3,label:'Level 3+'},{value:4,label:'Level 4+'},{value:5,label:'Level 5+'}]} placeholder="Level"/>
                    <Input label="Search Radius (km)" type="number" value={settings.alertRadiusKm} onChange={e=>updateSettings({notifications:{...settings,alertRadiusKm:Number(e.target.value)}})} min={5} max={200}/>
                  </div>
                  <div className="grid gap-4 md:grid-cols-2">
                    <Input label="Earliest Alert" type="time" value={settings.alertTimeWindow.start} onChange={e=>updateSettings({notifications:{...settings,alertTimeWindow:{...settings.alertTimeWindow,start:e.target.value}}}}) />
                    <Input label="Latest Alert" type="time" value={settings.alertTimeWindow.end} onChange={e=>updateSettings({notifications:{...settings,alertTimeWindow:{...settings.alertTimeWindow,end:e.target.value}}}}) />
                  </div>
                  <Input label="Max Wind (knots)" type="number" value={settings.maxWindKnots} onChange={e=>updateSettings({notifications:{...settings,maxWindKnots:Number(e.target.value)}})} min={0} max={30} />
                </CardContent>
              </Card>

              <Card variant="outlined" className="mb-6 border-emerald-200 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-900/10">
                <CardContent className="flex items-center gap-3"><Waves className="h-5 w-5 text-emerald-600"/><div><h3 className="font-medium text-emerald-800 dark:text-emerald-200">How Alerts Work</h3><ul className="text-sm text-emerald-700 dark:text-emerald-300 mt-1 space-y-1"><li>• Checks forecast every morning at 6am</li><li>• Alerts if ANY spot within radius scores ≥70 for your level</li><li>• Respects your time window and wind limit</li><li>• Max 1 alert per day per location</li><li>• Unsubscribe anytime from this page</li></ul></div></CardContent>
              </Card>

              <div className="flex gap-2 justify-end"><Button variant="secondary" onClick={()=>updateSettings({notifications:{...settings,alertsEnabled:false}})}><BellOff className="h-4 w-4"/>Disable All</Button><Button onClick={handleSave} loading={loading}><Save className="h-4 w-4"/>Save Settings</Button></div>

              {status==='success' && <Badge variant="success" className="mt-4">Settings saved!</Badge>}
              {status==='error' && <Badge variant="danger" className="mt-4">Failed to save</Badge>}
            </>
          )}
        </div>
      </section>
    </div>
  );
}