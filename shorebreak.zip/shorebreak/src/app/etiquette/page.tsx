'use client';
import { Card, CardContent, CardTitle } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Waves, UserCheck, AlertTriangle, Heart, ArrowRight, ArrowLeft, X, CheckCircle } from 'lucide-react';
import { clsx } from 'clsx';
import { useState } from 'react';

const rules = [
  {id:'priority',title:'Right of Way',icon:UserCheck,desc:'The surfer closest to the peak has priority. Do not drop in on someone already riding.',do:[],dont:['Dropping in','Snaking (paddling around to get priority)']},
  {id:'dropping',title:'Don\'t Drop In',icon:AlertTriangle,desc:'Taking off on a wave someone else is already riding is the #1 etiquette violation.',do:['Yell "yours!" if unsure','Pull back if someone has it'],dont:['Paddle for a wave someone is on','Ignore priority']},
  {id:'paddleout',title:'Paddle Out Wide',icon=ArrowRight,desc:'Use the channel to paddle out. Don\'t paddle through the lineup where people are riding.',do:['Stay wide of the peak','Wait for set to pass'],dont:['Paddle through the impact zone','Cut across someone\'s ride']},
  {id:'apologize',title:'Apologize for Mistakes',icon:Heart,desc:'If you drop in, get in the way, or collide - acknowledge it. A quick "sorry" goes a long way.',do:['Make eye contact','Say sorry','Learn from it'],dont:['Ignore it','Get defensive','Blame others']},
  {id:'share',title:'Share Waves',icon:Waves,desc:'Don\'t hog every set wave. Let others have turns, especially at crowded spots.',do:['Rotate on peaks','Encourage others'],dont:['Catch every wave','Sit deepest every time']},
  {id:'locals',title:'Respect Locals',icon=UserCheck,desc:'Locals know the spot best. Give them space and respect. You\'re a guest.',do:['Observe before paddling out','Be friendly','Follow local customs'],dont:['Act entitled','Crowd the peak','Leave trash']},
  {id:'control',title:'Board Control',icon=X,desc:'Never let go of your board in a crowd. A loose board is a dangerous projectile.',do:['Hold rails when falling','Turtle roll/duck dive properly','Use a leash always'],dont:['Ditch board in whitewater','Kick board away','Surf leashless in crowds']},
];

const quiz = [
  {q:'You\'re paddling for a wave. Someone deeper is already up and riding. What do you do?',a:['Keep paddling - I was here first','Pull back and let them have it','Try to sneak around them'],correct:1},
  {q:'You accidentally drop in on someone. What\'s the right response?',a:['Pretend it didn\'t happen','Yell at them for being in your way','Apologize immediately'],correct:2},
  {q:'Where should you paddle out at a point break?',a:['Straight through the lineup','Wide around the breaking waves','Right at the peak'],correct:1},
  {q:'Your leash breaks and your board is heading toward others. What do you do?',a:['Swim after it','Yell "BOARD!" and try to intercept','Ignore it - not my problem'],correct:1},
  {q:'A local surfer gives you a dirty look. Best response?',a:['Stare back','Smile and give space','Paddle right next to them'],correct:1},
];

export default function EtiquettePage() {
  const [showQuiz, setShowQuiz] = useState(false);
  const [answers, setAnswers] = useState<Record<number,number>>({});
  const [submitted, setSubmitted] = useState(false);

  const score = Object.entries(quiz).reduce((s,[i,a])=>s+(answers[Number(i)]===quiz[Number(i)].correct?1:0),0);

  return (
    <div className="min-h-screen">
      <section className="section">
        <div className="container max-w-3xl">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
            <div><h1 className="page-title">Surf Etiquette</h1><p className="page-subtitle">The unwritten rules that keep everyone safe and stoked</p></div>
            <Button variant="outline" onClick={()=>setShowQuiz(!showQuiz)}>{showQuiz?'Hide Quiz':'Take Quiz'}</Button>
          </div>

          {!showQuiz && (
            <>
              <Card variant="elevated" className="mb-6">
                <CardContent className="text-center py-8"><Waves className="h-12 w-12 mx-auto mb-4 text-ocean-600"/><h3 className="text-xl font-bold mb-2">The Golden Rule</h3><p className="text-slate-600 dark:text-slate-400 max-w-md mx-auto">Respect others, respect the ocean, respect yourself. Everyone wants to catch waves - share the stoke.</p></CardContent>
              </Card>

              <div className="space-y-4">
                {rules.map(r => (
                  <Card key={r.id} variant="elevated">
                    <CardContent>
                      <div className="flex items-start gap-3"><span className="p-2 rounded-lg bg-ocean-100 dark:bg-ocean-900/30"><r.icon className="h-5 w-5 text-ocean-600"/></span><div className="flex-1"><h3 className="font-semibold text-slate-900 dark:text-white">{r.title}</h3><p className="text-sm text-slate-600 dark:text-slate-400">{r.desc}</p></div></div>
                      <div className="mt-4 grid gap-3 md:grid-cols-2">
                        <div><h4 className="text-sm font-medium text-emerald-700 dark:text-emerald-300 mb-2 flex items-center gap-1"><CheckCircle className="h-3.5 w-3.5"/> Do</h4><ul className="space-y-1 text-sm text-slate-600 dark:text-slate-400">{r.do.map((d,i)=>(<li key={i} className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-emerald-500"/>{d}</li>))}</ul></div>
                        <div><h4 className="text-sm font-medium text-red-700 dark:text-red-300 mb-2 flex items-center gap-1"><X className="h-3.5 w-3.5"/> Don't</h4><ul className="space-y-1 text-sm text-slate-600 dark:text-slate-400">{r.dont.map((d,i)=>(<li key={i} className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-red-500"/>{d}</li>))}</ul></div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </>
          )}

          {showQuiz && (
            <Card variant="elevated">
              <CardTitle>Etiquette Quiz</CardTitle>
              <CardContent>
                {quiz.map((q,i)=>(<div key={i} className="mb-6"><p className="font-medium mb-3">{i+1}. {q.q}</p><div className="space-y-2">{q.a.map((a,j)=>(<label key={j} className="flex items-center gap-2 cursor-pointer p-3 rounded-lg border transition" style={{borderColor:submitted&&answers[i]===j?(answers[i]===q.correct?'emerald-500':'red-500'):'slate-300 dark:border-slate-600',backgroundColor:submitted&&answers[i]===j?(answers[i]===q.correct?'emerald-50':'red-50'):'transparent'}}><input type="radio" name={String(i)} value={j} checked={answers[i]===j} onChange={()=>setAnswers({...answers,[i]:j})} disabled={submitted} className="w-4 h-4 text-ocean-600"/><span className="text-sm text-slate-700 dark:text-slate-300">{a}</span></label>))}{submitted&&answers[i]!==q.correct&&(<p className="mt-1 text-sm text-red-600">Correct: {q.a[q.correct]}</p>)}</div></div>))}
                <div className="flex gap-4">
                  {!submitted ? <Button onClick={()=>setSubmitted(true)}>Submit Answers</Button> : <Button variant="secondary" onClick={()=>{setSubmitted(false);setAnswers({});}}>Retake</Button>}
                  {submitted && <span className="self-center font-medium text-lg">Score: {score}/{quiz.length}</span>}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </section>
    </div>
  );
}