'use client';
import { useState } from 'react';
import { useForecast } from '@/hooks/useForecast';
import { useUser } from '@/hooks/useUser';
import { Card, CardContent, CardTitle } from '@/components/ui/Card';
import { Badge, SuitabilityBadge } from '@/components/ui/Badge';
import { Select } from '@/components/ui/Select';
import { Waves, Wind, Thermometer, Tide, Sun, Calendar, ChevronDown } from 'lucide-react';
import { clsx } from 'clsx';
import { fmtDate, dayName, bodyH, windDesc, relWind, fmtTemp, fmtWave, fmtWind } from '@/lib/utils/units';
import type { DailyForecast, HourlyForecast } from '@/types';

export default function ForecastPage() {
  const { profile } = useUser();
  const level = profile?.level || 1;
  const lat = profile?.settings?.units ? 37.7749 : 37.7749;
  const lon = -122.4194;
  const [unitSys, setUnitSys] = useState<'metric'|'imperial'>('imperial');
  const [view, setView] = useState<'simple'|'detailed'>('simple');
  const [coast, setCoast] = useState(270);
  const { daily, hourly, loading, error, refetch, updated } = useForecast(lat, lon, level, coast);

  if (loading && !daily) return <div className="section container"><div className="flex h-64 items-center justify-center"><div className="animate-spin rounded-full h-12 w-12 border-4 border-ocean-600 border-t-transparent"/></div></div>;

  return (
    <div className="min-h-screen">
      <section className="section">
        <div className="container">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
            <div><h1 className="page-title">7-Day Forecast</h1><p className="page-subtitle">Plan your sessions for the week ahead</p></div>
            <div className="flex flex-wrap items-center gap-2">
              <Select value={unitSys} onChange={e=>setUnitSys(e.target.value as 'metric'|'imperial')} options={[{value:'imperial',label:'Imperial (ft/°F/kt)'},{value:'metric',label:'Metric (m/°C/kph)'}]} placeholder="Units"/>
              <Select value={view} onChange={e=>setView(e.target.value as 'simple'|'detailed')} options={[{value:'simple',label:'Simple'},{value:'detailed',label:'Detailed'}]} placeholder="View"/>
              <button onClick={refetch} className="btn btn-secondary"><Sun className="h-4 w-4"/> Refresh</button>
            </div>
          </div>

          {error && <div className="mb-6 p-4 rounded-lg bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-800 dark:text-red-200">{error}</div>}

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 mb-8">
            {daily.slice(0, 7).map(d => (
              <Card key={d.date} variant="elevated" className="relative">
                <CardContent>
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <p className="font-semibold text-slate-900 dark:text-white">{dayName(d.date)}</p>
                      <p className="text-sm text-slate-500">{fmtDate(d.date)}</p>
                    </div>
                    <SuitabilityBadge score={Math.min(100, Math.max(0, 70 - Math.abs(d.maxWaveHeight - 3) * 10))} />
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between"><span className="text-slate-500">Waves</span><span className="font-medium">{fmtWave(d.maxWaveHeight, unitSys==='metric'?'m':'ft')} - {fmtWave(d.minWaveHeight, unitSys==='metric'?'m':'ft')}</span></div>
                    <div className="flex justify-between"><span className="text-slate-500">Period</span><span className="font-medium">{d.dominantPeriod}s</span></div>
                    <div className="flex justify-between"><span className="text-slate-500">Wind</span><span className="font-medium">{d.windSummary.speed} kt {d.windSummary.directionCardinal}</span></div>
                    <div className="flex justify-between"><span className="text-slate-500">Tides</span><span className="font-medium">{d.tideHigh?.time?fmtTime(d.tideHigh.time):'--'} / {d.tideLow?.time?fmtTime(d.tideLow.time):'--'}</span></div>
                    <div className="flex justify-between"><span className="text-slate-500">Sun</span><span className="font-medium">{fmtTime(d.sunrise)} - {fmtTime(d.sunset)}</span></div>
                  </div>
                  <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-700">
                    <p className="text-xs text-slate-500">Best for level {level}: {d.maxWaveHeight <= (level===1?2:level===2?3:level===3?4:level===4?6:8) ? '✓ Good fit' : '⚠ May be too big'}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {view === 'detailed' && daily[0] && (
            <Card>
              <CardTitle>Detailed Charts</CardTitle>
              <CardContent>
                <div className="grid gap-6 md:grid-cols-2">
                  <div>
                    <h4 className="font-medium mb-3">Swell Height (7 days)</h4>
                    <div className="h-64"><canvas id="swellChart"></canvas></div>
                  </div>
                  <div>
                    <h4 className="font-medium mb-3">Wind Speed (7 days)</h4>
                    <div className="h-64"><canvas id="windChart"></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </section>
    </div>
  );
}
function fmtTime(s:string){return new Date(s).toLocaleTimeString([],{hour:'numeric',minute:'2-digit',hour12:true});}