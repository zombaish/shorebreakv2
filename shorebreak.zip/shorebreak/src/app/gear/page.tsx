'use client';
import { useState } from 'react';
import { useUser } from '@/hooks/useUser';
import { Card, CardContent, CardTitle } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Select } from '@/components/ui/Select';
import { Waves, Shirt, ShoppingBag, CheckCircle, Package, Truck, Zap, Shield } from 'lucide-react';
import { clsx } from 'clsx';

const boards = [
  {type:'foam',name:'Foam Board (Soft-top)',volMult:0.9,desc:'Maximum buoyancy, forgiving, safe for learners',buyRent:'rent',reason:'Start here - cheap to rent, durable, safe'},
  {type:'funboard',name:'Funboard / Mini-mal',volMult:0.7,desc:'More maneuverable than foam, good for progressing',buyRent:'buy',reason:'Great first purchase - lasts through Level 2-3'},
  {type:'fish',name:'Fish',volMult:0.55,desc:'Wide, thick, fast - great for small waves',buyRent:'buy',reason:'Level 3+ - adds speed and flow in weak surf'},
  {type:'shortboard',name:'Shortboard',volMult:0.4,desc:'High performance, requires skill and fitness',buyRent:'buy',reason:'Level 4+ only - steep learning curve'},
  {type:'longboard',name:'Longboard',volMult:1.0,desc:'Maximum glide, nose riding, classic style',buyRent:'buy',reason:'Alternative path - different skill set'},
];

const wetsuits = [
  {temp:'65-70°F (18-21°C)',gear:'2mm Spring Suit / Jacket',accessories:[]},
  {temp:'60-65°F (15-18°C)',gear:'3/2mm Full Suit',accessories:[]},
  {temp:'55-60°F (13-15°C)',gear:'4/3mm Full Suit',accessories:['3mm Boots']},
  {temp:'50-55°F (10-13°C)',gear:'4/3mm or 5/4mm Hooded',accessories:['5mm Boots','3mm Gloves','Hood']},
  {temp:'Below 50°F (<10°C)',gear:'5/4mm or 6/5mm Hooded',accessories:['7mm Boots','5mm Gloves','Hood','Thermal Vest']},
];

const essentials = [
  {cat:'board',item:'Surfboard',reason:'Matched to your level, weight, conditions'},
  {cat:'board',item:'Leash',reason:'Keeps board close, prevents loss/injury'},
  {cat:'board',item:'Wax or Traction Pad',reason:'Grip for feet - essential'},
  {cat:'board',item:'Fins (thruster/quad)',reason:'Drive and control - match board'},
  {cat:'wetsuit',item:'Wetsuit',reason:'Thermal protection - match water temp'},
  {cat:'wetsuit',item:'Booties',reason:'Feet get cold first - critical <60°F'},
  {cat:'wetsuit',item:'Gloves',reason:'Hands lose dexterity when cold'},
  {cat:'wetsuit',item:'Hood',reason:'Head heat loss is huge - <55°F essential'},
  {cat:'safety',item:'Rash Guard (UPF 50+)',reason:'Sun protection, prevents rash'},
  {cat:'safety',item:'Reef-Safe Sunscreen SPF 30+',reason:'Protect skin AND coral reefs'},
  {cat:'safety',item:'Ear Plugs',reason:'Prevent surfer\'s ear (exostosis)'},
  {cat:'accessory',item:'Board Bag',reason:'Protects dings in transit/storage'},
  {cat:'accessory',item:'Fin Key + Spare Fins',reason:'Fins loosen - always carry spare'},
  {cat:'accessory',item:'Surf Poncho / Changing Towel',reason:'Warmth & privacy changing'},
  {cat:'accessory',item:'First Aid Kit',reason:'Cuts, reef rash, stings happen'},
  {cat:'accessory',item:'Water Bottle / Electrolytes',reason:'Hydration = longer sessions'},
];

export default function GearPage() {
  const { profile, updateSettings } = useUser();
  const [weight, setWeight] = useState(profile?.weightKg || 75);
  const [height, setHeight] = useState(profile?.heightCm || 175);
  const [waterTemp, setWaterTemp] = useState(62);
  const level = profile?.level || 1;
  const unitSys = profile?.settings?.units || {waveHeight:'ft',temperature:'fahrenheit',windSpeed:'knots',distance:'km'};

  const vol = Math.round((weight * boards.find(b=>b.type=== (level<=2?'foam':level===3?'funboard':'fish'))!.volMult));
  const recBoard = boards.find(b=>b.type=== (level<=2?'foam':level===3?'funboard':'fish'))!;
  const suit = wetsuits.find(w=>{const t=w.temp.match(/(\d+)/); return t&&waterTemp>=Number(t[1].split('-')[1])||waterTemp<=Number(t[1].split('-')[0])})||wetsuits[wetsuits.length-1];

  return (
    <div className="min-h-screen">
      <section className="section">
        <div className="container max-w-4xl">
          <h1 className="page-title">Gear Guide</h1>
          <p className="page-subtitle">Find the right equipment for your level, body, and conditions</p>

          <Card variant="elevated" className="mb-6">
            <CardTitle>Your Profile</CardTitle>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-4">
                <Input label="Weight (kg)" type="number" value={weight} onChange={e=>setWeight(Number(e.target.value))} min={30} max={150}/>
                <Input label="Height (cm)" type="number" value={height} onChange={e=>setHeight(Number(e.target.value))} min={100} max={220}/>
                <Input label={`Water Temp (${unitSys.temperature==='celsius'?'°C':'°F'})`} type="number" value={waterTemp} onChange={e=>setWaterTemp(Number(e.target.value))} min={0} max={35}/>
                <Select value={level} onChange={e=>{}} options={[{value:1,label:'Level 1'},{value:2,label:'Level 2'},{value:3,label:'Level 3'},{value:4,label:'Level 4'},{value:5,label:'Level 5'}]} placeholder="Your Level" disabled/>
              </div>
            </CardContent>
          </Card>

          <Card variant="elevated" className="mb-6">
            <CardTitle className="flex items-center gap-2"><Waves className="h-5 w-5"/>Board Finder</CardTitle>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 bg-ocean-50 dark:bg-ocean-900/20 rounded-lg border border-ocean-200 dark:border-ocean-800">
                  <div className="flex items-center justify-between mb-2"><h4 className="font-semibold">{recBoard.name}</h4><Badge variant={recBoard.buyRent==='buy'?'success':'info'}>{recBoard.buyRent.toUpperCase()}</Badge></div>
                  <p className="text-sm text-slate-600 dark:text-slate-400 mb-3">{recBoard.desc}</p>
                  <div className="grid gap-2 md:grid-cols-3 text-sm"><div><strong>Recommended Volume:</strong> ~{vol}L</div><div><strong>Why:</strong> {recBoard.reason}</div><div><strong>Level:</strong> {level<=2?'1-2':level===3?'3':'4+'}</div></div>
                </div>
                <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
                  {boards.map(b=>(
                    <div key={b.type} className={clsx('p-3 rounded-lg border transition',b.type===recBoard.type?'border-ocean-500 bg-ocean-50 dark:bg-ocean-900/20':'border-slate-200 dark:border-slate-700')}>
                      <div className="font-medium">{b.name}</div>
                      <p className="text-xs text-slate-500 mb-2">{b.desc}</p>
                      <div className="flex items-center justify-between"><Badge variant={b.buyRent==='buy'?'success':'info'} size="sm">{b.buyRent}</Badge><span className="text-xs text-slate-500">~{Math.round(weight*b.volMult)}L</span></div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card variant="elevated" className="mb-6">
            <CardTitle className="flex items-center gap-2"><Shirt className="h-5 w-5"/>Wetsuit Finder</CardTitle>
            <CardContent>
              <div className="space-y-3">
                <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
                  <p className="font-semibold mb-1">Recommended for {waterTemp}°F</p>
                  <p className="text-lg font-medium text-blue-700 dark:text-blue-300">{suit.gear}</p>
                  {suit.accessories.length>0 && <p className="text-sm text-blue-600 dark:text-blue-400 mt-1">Add: {suit.accessories.join(', ')}</p>}
                </div>
                <div className="overflow-x-auto"><table className="w-full text-sm"><thead><tr className="border-b border-slate-200 dark:border-slate-700"><th className="text-left py-2">Water Temp</th><th className="text-left py-2">Wetsuit</th><th className="text-left py-2">Accessories</th></tr></thead><tbody>{wetsuits.map(w=>(<tr key={w.temp} className="border-b border-slate-100 dark:border-slate-800"><td className="py-2">{w.temp}</td><td className="py-2 font-medium">{w.gear}</td><td className="py-2 text-slate-600 dark:text-slate-400">{w.accessories.join(', ')||'None'}</td></tr>))}</tbody></table></div>
              </div>
            </CardContent>
          </Card>

          <Card variant="elevated" className="mb-6">
            <CardTitle className="flex items-center gap-2"><Package className="h-5 w-5"/>Essentials Checklist</CardTitle>
            <CardContent>
              <div className="space-y-2">
                {['board','wetsuit','safety','accessory'].map(cat=>(
                  <div key={cat} className="border-t border-slate-200 dark:border-slate-700 pt-4 first:border-0">
                    <h4 className="font-medium capitalize mb-2">{cat}s</h4>
                    <div className="space-y-1">
                      {essentials.filter(e=>e.cat===cat).map(e=>(
                        <label key={e.item} className="flex items-center gap-2 cursor-pointer"><input type="checkbox" className="w-4 h-4 rounded border-slate-300 text-ocean-600"/><span className="text-sm">{e.item}</span><span className="text-xs text-slate-500 ml-auto">({e.reason})</span></label>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card variant="elevated">
            <CardTitle className="flex items-center gap-2"><Shield className="h-5 w-5"/>Editorial Brand Suggestions (Not Sponsored)</CardTitle>
            <CardContent>
              <div className="space-y-4">
                {[
                  {cat:'Foam Boards',items:[{tier:'budget',b:'Wavestorm',m:'8\' Classic',p:'$200-250',r:'Best value, everywhere'},{tier:'mid',b:'Catch Surf',m:'Odysea Log',p:'$300-350',r:'Better shape, fun colors'},{tier:'premium',b:'Softlite',m:'Pro',p:'$400+',r:'Premium construction'}]},
                  {cat:'Funboards',items:[{tier:'budget',b:'Torq',m:'TET Funboard',p:'$450-550',r:'Durable epoxy tech'},{tier:'mid',b:'Degree 33',m:'The Ultimate',p:'$600-700',r:'Great all-rounder'},{tier:'premium',b:'Pyzel',m:'The Gremlin',p:'$800+',r:'Pro-level funboard'}]},
                  {cat:'Wetsuits',items:[{tier:'budget',b:'O\'Neill',m:'React',p:'$150-200',r:'Solid entry-level'},{tier:'mid',b:'Rip Curl',m:'Flashbomb',p:'$300-400',r:'Great stretch/warmth'},{tier:'premium',b:'Patagonia',m:'R1/R2 Yulex',p:'$450+',r:'Eco-friendly, top warmth'}]},
                ].map(c=>(<div key={c.cat}><h4 className="font-medium mb-2">{c.cat}</h4><div className="grid gap-2 md:grid-cols-3">{c.items.map(i=>(<div key={i.b} className="p-3 rounded-lg border border-slate-200 dark:border-slate-700"><span className={clsx('text-xs font-medium px-2 py-0.5 rounded',i.tier==='budget'&&'bg-slate-100 dark:bg-slate-800',i.tier==='mid'&&'bg-blue-100 dark:bg-blue-900/30',i.tier==='premium'&&'bg-amber-100 dark:bg-amber-900/30')}>{i.tier}</span><p className="font-medium mt-1">{i.b} {i.m}</p><p className="text-sm text-slate-500">{i.p}</p><p className="text-xs text-slate-400 mt-1">{i.r}</p></div>))}</div></div>))}
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}