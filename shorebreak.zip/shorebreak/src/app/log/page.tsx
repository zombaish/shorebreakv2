'use client';
import { useState } from 'react';
import { useUser } from '@/hooks/useUser';
import { Card, CardContent, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Select } from '@/components/ui/Select';
import { Textarea } from '@/components/ui/Input';
import { Badge, SuitabilityBadge } from '@/components/ui/Badge';
import { Plus, Trash2, Calendar, Clock, Star, Waves, Wind, Thermometer, BarChart2, TrendingUp } from 'lucide-react';
import { clsx } from 'clsx';
import { fmtDate, bodyH, fmtTemp } from '@/lib/utils/units';
import type { SessionEntry } from '@/types';

const mockSpots = [{id:'1',name:'Ocean Beach',lat:37.75,lon:-122.51},{id:'2',name:'Pacifica',lat:37.61,lon:-122.49},{id:'3',name:'Linda Mar',lat:37.59,lon:-122.48}];

export default function LogPage() {
  const { profile, sessionLog, addSessionEntry } = useUser();
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({date:new Date().toISOString().split('T')[0],spotId:'',duration:90,skills:'',rating:3,notes:'',conditions:{waveHeight:3,period:11,wind:10,windDir:'W',waterTemp:58,tide:'mid'}});

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const spot = mockSpots.find(s=>s.id===form.spotId) || {name:'Unknown',id:'0',lat:0,lon:0};
    addSessionEntry({date:form.date,spotId:spot.id,spotName:spot.name,conditions:{waveHeightFt:form.conditions.waveHeight,wavePeriodSec:form.conditions.period,windSpeedKnots:form.conditions.wind,windDirection:form.conditions.windDir,waterTempF:form.conditions.waterTemp,tide:form.conditions.tide},durationMinutes:form.duration,skillsWorkedOn:form.skills.split(',').map(s=>s.trim()).filter(Boolean),rating:form.rating,notes:form.notes,levelAtTime:profile?.level||1});
    setShowForm(false);
    setForm({date:new Date().toISOString().split('T')[0],spotId:'',duration:90,skills:'',rating:3,notes:'',conditions:{waveHeight:3,period:11,wind:10,windDir:'W',waterTemp:58,tide:'mid'}});
  };

  const insights = sessionLog.length > 0 ? {
    bestHeight: sessionLog.reduce((a,b)=>b.conditions.waveHeightFt>a.conditions.waveHeightFt?b:a).conditions.waveHeightFt,
    avgRating: Math.round(sessionLog.reduce((a,b)=>a+b.rating,0)/sessionLog.length*10)/10,
    totalSessions: sessionLog.length,
    totalHours: Math.round(sessionLog.reduce((a,b)=>a+b.durationMinutes,0)/60*10)/10,
  } : null;

  return (
    <div className="min-h-screen">
      <section className="section">
        <div className="container max-w-3xl">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
            <div><h1 className="page-title">Session Log</h1><p className="page-subtitle">Track your sessions, see patterns, measure progress</p></div>
            <Button onClick={()=>setShowForm(true)}><Plus className="h-4 w-4"/> Log Session</Button>
          </div>

          {showForm && (
            <Card variant="elevated" className="mb-6 animate-in">
              <CardTitle>New Session</CardTitle>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <Input label="Date" type="date" value={form.date} onChange={e=>setForm({...form,date:e.target.value})} required/>
                    <Select label="Spot" value={form.spotId} onChange={e=>setForm({...form,spotId:e.target.value})} options={mockSpots.map(s=>({value:s.id,label:s.name}))} placeholder="Select spot" required/>
                  </div>
                  <div className="grid gap-4 md:grid-cols-3">
                    <Input label="Duration (min)" type="number" value={form.duration} onChange={e=>setForm({...form,duration:Number(e.target.value)})} min={15} max={480}/>
                    <Input label="Rating (1-5)" type="number" value={form.rating} onChange={e=>setForm({...form,rating:Number(e.target.value)})} min={1} max={5}/>
                    <Select label="Tide" value={form.conditions.tide} onChange={e=>setForm({...form,conditions:{...form.conditions,tide:e.target.value as 'high'|'low'|'mid'}})} options={[{value:'high',label:'High'},{value:'mid',label:'Mid'},{value:'low',label:'Low'}]} placeholder="Tide"/>
                  </div>
                  <div className="grid gap-4 md:grid-cols-3">
                    <Input label="Wave Height (ft)" type="number" step="0.5" value={form.conditions.waveHeight} onChange={e=>setForm({...form,conditions:{...form.conditions,waveHeight:Number(e.target.value)}})} min={0.5} max={20}/>
                    <Input label="Period (s)" type="number" value={form.conditions.period} onChange={e=>setForm({...form,conditions:{...form.conditions,period:Number(e.target.value)}})} min={4} max={20}/>
                    <Input label="Wind (kt)" type="number" value={form.conditions.wind} onChange={e=>setForm({...form,conditions:{...form.conditions,wind:Number(e.target.value)}})} min={0} max={40}/>
                  </div>
                  <div className="grid gap-4 md:grid-cols-2">
                    <Select label="Wind Dir" value={form.conditions.windDir} onChange={e=>setForm({...form,conditions:{...form.conditions,windDir:e.target.value}})} options={['N','NE','E','SE','S','SW','W','NW'].map(d=>({value:d,label:d}))} placeholder="Wind Dir"/>
                    <Input label="Water Temp (°F)" type="number" value={form.conditions.waterTemp} onChange={e=>setForm({...form,conditions:{...form.conditions,waterTemp:Number(e.target.value)}})} min={30} max={85}/>
                  </div>
                  <Input label="Skills Worked On (comma separated)" placeholder="e.g. bottom turns, paddling, wave selection" value={form.skills} onChange={e=>setForm({...form,skills:e.target.value})}/>
                  <Textarea label="Notes" placeholder="How did it feel? What clicked? What to work on?" value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})} rows={3}/>
                  <div className="flex gap-2"><Button type="submit">Save Session</Button><Button type="button" variant="secondary" onClick={()=>setShowForm(false)}>Cancel</Button></div>
                </form>
              </CardContent>
            </Card>
          )}

          {insights && (
            <div className="grid gap-4 md:grid-cols-4 mb-6">
              <Card><CardContent className="text-center"><p className="text-3xl font-bold text-ocean-600">{insights.totalSessions}</p><p className="text-sm text-slate-500">Total Sessions</p></CardContent></Card>
              <Card><CardContent className="text-center"><p className="text-3xl font-bold text-ocean-600">{insights.totalHours}h</p><p className="text-sm text-slate-500">Hours in Water</p></CardContent></Card>
              <Card><CardContent className="text-center"><p className="text-3xl font-bold text-ocean-600">{insights.avgRating}/5</p><p className="text-sm text-slate-500">Avg Rating</p></CardContent></Card>
              <Card><CardContent className="text-center"><p className="text-3xl font-bold text-ocean-600">{insights.bestHeight}ft</p><p className="text-sm text-slate-500">Biggest Wave</p></CardContent></Card>
            </div>
          )}

          <Card>
            <CardTitle className="flex items-center justify-between"><span>Your Sessions</span>{sessionLog.length===0&&<span className="text-sm text-slate-500">No sessions yet - start logging!</span>}</CardTitle>
            <CardContent>
              {sessionLog.length === 0 ? (
                <div className="text-center py-12 text-slate-500"><BarChart2 className="h-12 w-12 mx-auto mb-4 opacity-50"/><p>No sessions logged yet. Click "Log Session" to start tracking your progress.</p></div>
              ) : (
                <div className="space-y-3 max-h-[600px] overflow-auto">
                  {sessionLog.map(s=>(<div key={s.id} className="p-4 rounded-lg border border-slate-200 dark:border-slate-700 flex flex-col md:flex-row md:items-center gap-4"><div className="flex-1 min-w-0"><div className="flex items-center gap-3 flex-wrap"><h4 className="font-medium">{s.spotName}</h4><Badge variant="info" size="sm">{fmtDate(s.date)}</Badge><SuitabilityBadge score={Math.max(0,100-Math.abs(s.conditions.waveHeightFt-3)*15)} /></div><div className="flex flex-wrap gap-4 text-sm text-slate-600 dark:text-slate-400 mt-1"><span className="flex items-center gap-1"><Waves className="h-3.5 w-3.5"/>{s.conditions.waveHeightFt}ft @ {s.conditions.wavePeriodSec}s</span><span className="flex items-center gap-1"><Wind className="h-3.5 w-3.5"/>{s.conditions.windSpeedKnots}kt {s.conditions.windDirection}</span><span className="flex items-center gap-1"><Thermometer className="h-3.5 w-3.5"/>{s.conditions.waterTempF}°F</span><span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5"/>{s.durationMinutes}min</span></div>{s.skillsWorkedOn.length>0&&<div className="mt-2 flex flex-wrap gap-1">{s.skillsWorkedOn.map((sk,i)=>(<Badge key={i} variant="default" size="sm">{sk}</Badge>))}</div>{s.notes&&<p className="mt-2 text-sm text-slate-500 italic">"{s.notes}"</p>}</div><div className="flex items-center gap-2"><span className="flex items-center gap-1 text-amber-500">{Array.from({length:s.rating},(_,i)=><Star key={i} className="h-4 w-4 fill-current"/>)}</span><Button variant="ghost" size="sm" onClick={()=>{}}><Trash2 className="h-4 w-4"/></Button></div></div>))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}