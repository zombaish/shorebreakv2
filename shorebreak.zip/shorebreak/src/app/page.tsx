'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useForecast, useSearch, useGeo } from '@/hooks/useForecast';
import { useUser, useLevel } from '@/hooks/useUser';
import { useTheme } from '@/hooks/useTheme';
import { Button } from '@/components/ui/Button';
import { Card, CardContent, CardTitle } from '@/components/ui/Card';
import { Badge, SuitabilityBadge, LevelBadge, HazardBadge } from '@/components/ui/Badge';
import { Input } from '@/components/ui/Input';
import { Select } from '@/components/ui/Select';
import { Search, MapPin, Sun, Moon, Waves, Wind, Thermometer, Tide, Clock, AlertTriangle, CheckCircle, X, Loader2, Locate, ChevronDown } from 'lucide-react';
import { clsx } from 'clsx';
import { fmtTime, fmtDate, bodyH, windDesc, relWind, fmtTemp, hrsToSunset, isDay } from '@/lib/utils/units';

export default function Home() {
  const { profile, level, setLevel } = useUser();
  const { theme, resolvedTheme, toggleTheme } = useTheme();
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearch, setShowSearch] = useState(false);
  const { results, loading: searchLoading, search } = useSearch();
  const { location: geoLoc, request: requestGeo } = useGeo();
  const [coastAngle, setCoastAngle] = useState(270);
  const [unitSys, setUnitSys] = useState<'metric'|'imperial'>('imperial');
  const [lat, setLat] = useState(37.7749);
  const [lon, setLon] = useState(-122.4194);
  const [locName, setLocName] = useState('San Francisco, CA');
  const { current, hourly, scored, bestWindowToday, spots, loading, error, refetch, updated } = useForecast(lat, lon, level, coastAngle);

  useEffect(() => { if (results.length > 0) { const r = results[0]; setLat(r.lat); setLon(r.lon); setLocName(r.name); setShowSearch(false); setSearchQuery(''); } }, [results]);
  useEffect(() => { const saved = localStorage.getItem('sb_units'); if (saved) setUnitSys(saved as 'metric'|'imperial'); }, []);
  useEffect(() => { localStorage.setItem('sb_units', unitSys); }, [unitSys]);

  const handleLocSelect = (r: typeof results[0]) => { setLat(r.lat); setLon(r.lon); setLocName(r.name); setShowSearch(false); setSearchQuery(''); };

  if (loading && !current) return <div className="flex h-[60vh] items-center justify-center"><Loader2 className="h-12 w-12 animate-spin text-ocean-600"/></div>;

  const suit = current ? SuitabilityBadge({ score: scored[0]?.score?.overallScore || 0 }) : null;
  const reasons = scored[0]?.score?.reasons || [];
  const hazards = scored[0]?.score?.hazards || [];

  return (
    <div className="min-h-screen">
      <section className="section">
        <div className="container">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
            <div>
              <h1 className="page-title">Today's Verdict</h1>
              <p className="page-subtitle">Plain-English surf check for <strong>{locName}</strong></p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <Button variant="outline" onClick={() => setShowSearch(!showSearch)} className="gap-2"><Search className="h-4 w-4"/><span>Change Location</span></Button>
              <Button variant="ghost" size="sm" onClick={requestGeo} className="gap-1.5"><Locate className="h-4 w-4"/>Use My Location</Button>
              <Button variant="ghost" size="sm" onClick={toggleTheme}><Sun className="h-4 w-4"/></Button>
            </div>
          </div>

          {showSearch && (
            <div className="mb-6">
              <Input value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder="Search beach, city, or coast..." leftIcon={<Search className="h-5 w-5"/>} />
              {searchLoading && <div className="h-2 bg-slate-200 dark:bg-slate-700 animate-pulse rounded mb-2"/>}
              {results.length > 0 && (
                <div className="mt-2 space-y-1 max-h-60 overflow-auto">
                  {results.map(r => (
                    <button key={`${r.lat}-${r.lon}`} onClick={() => handleLocSelect(r)} className="w-full text-left p-3 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 flex items-center gap-3">
                      <MapPin className="h-5 w-5 text-ocean-600"/> <div><p className="font-medium text-slate-900 dark:text-white">{r.name}</p><p className="text-xs text-slate-500">{r.country}</p></div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {error && (
            <div className="mb-6 p-4 rounded-lg bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 flex items-center gap-3">
              <AlertTriangle className="h-5 w-5 text-red-600"/><div><p className="font-medium text-red-800 dark:text-red-200">Unable to load forecast</p><p className="text-sm text-red-600 dark:text-red-400">{error}</p></div><Button variant="ghost" size="sm" onClick={refetch}>Retry</Button>
            </div>
          )}

          {current && (
            <>
              <Card variant="elevated" className="mb-6">
                <CardContent className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
                  <div className="flex items-center gap-4">
                    <div className={clsx('w-20 h-20 rounded-2xl flex items-center justify-center text-3xl font-bold', scored[0]?.score?.suitability === 'good' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400' : scored[0]?.score?.suitability === 'okay' ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400' : 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400')}>
                      {scored[0]?.score?.suitability === 'good' ? '✓' : scored[0]?.score?.suitability === 'okay' ? '∼' : '✕'}
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-slate-900 dark:text-white">{suit ? suit.props.children : 'Loading...'}</p>
                      <p className="text-slate-600 dark:text-slate-400">for Level {level} ({useLevel().info.name})</p>
                    </div>
                  </div>
                  <div className="flex flex-wrap items-center gap-4 text-sm text-slate-600 dark:text-slate-400">
                    <span className="flex items-center gap-1.5"><Waves className="h-4 w-4"/>{bodyH(current.wave.height)} ({current.wave.height}ft)</span>
                    <span className="flex items-center gap-1.5"><Wind className="h-4 w-4"/>{windDesc(current.wind.speed, relWind(current.wind.direction, coastAngle))}</span>
                    <span className="flex items-center gap-1.5"><Thermometer className="h-4 w-4"/>{fmtTemp(current.waterTemp, unitSys==='metric'?'celsius':'fahrenheit')}</span>
                    <span className="flex items-center gap-1.5"><Tide className="h-4 w-4"/>Tide: {current.tide?.type || 'mid'}</span>
                  </div>
                </CardContent>
              </Card>

              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-6">
                <Card><CardContent className="text-center"><p className="text-3xl font-bold text-ocean-600 dark:text-ocean-400">{current.wave.height}ft</p><p className="text-sm text-slate-500">Wave Height</p><p className="text-xs text-slate-400">{bodyH(current.wave.height)}</p></CardContent></Card>
                <Card><CardContent className="text-center"><p className="text-3xl font-bold text-ocean-600 dark:text-ocean-400">{current.wave.period}s</p><p className="text-sm text-slate-500">Period</p><p className="text-xs text-slate-400">{current.wave.period>=12?'Clean':'Choppy'}</p></CardContent></Card>
                <Card><CardContent className="text-center"><p className="text-3xl font-bold text-ocean-600 dark:text-ocean-400">{current.wind.speed} kt</p><p className="text-sm text-slate-500">Wind</p><p className="text-xs text-slate-400">{windDesc(current.wind.speed, relWind(current.wind.direction, coastAngle))}</p></CardContent></Card>
                <Card><CardContent className="text-center"><p className="text-3xl font-bold text-ocean-600 dark:text-ocean-400">{fmtTemp(current.waterTemp, unitSys==='metric'?'celsius':'fahrenheit')}</p><p className="text-sm text-slate-500">Water Temp</p><p className="text-xs text-slate-400">{current.waterTemp<60?'Wetsuit needed':'Trunks OK'}</p></CardContent></Card>
              </div>

              <Card className="mb-6">
                <CardTitle>Why this verdict?</CardTitle>
                <CardContent>
                  <ul className="space-y-2">
                    {reasons.map((r, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-slate-600 dark:text-slate-300"><CheckCircle className="h-5 w-5 text-emerald-600 flex-shrink-0 mt-0.5"/>{r}</li>
                    ))}
                  </ul>
                </CardContent>
              </Card>

              {hazards.length > 0 && (
                <Card variant="outlined" className="mb-6 border-amber-200 dark:border-amber-800">
                  <CardTitle className="flex items-center gap-2 text-amber-700 dark:text-amber-300"><AlertTriangle className="h-5 w-5"/>Hazards to Watch</CardTitle>
                  <CardContent>
                    <div className="flex flex-wrap gap-2">{hazards.map(h => <HazardBadge key={h.type} type={h.type} />)}</div>
                    <div className="mt-3 space-y-1 text-sm text-slate-600 dark:text-slate-400">
                      {hazards.map(h => (
                        <p key={h.type} className="flex items-center gap-1.5"><span className="w-1.5 h-1.5 rounded-full bg-amber-500"/>{h.message}</p>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              <Card className="mb-6">
                <CardTitle>Best Window Today</CardTitle>
                <CardContent>
                  {bestWindowToday ? (
                    <div className="space-y-3">
                      <div className="flex flex-wrap items-center gap-4 text-sm">
                        <span className="font-medium">Best: {fmtTime(bestWindowToday.time)}</span>
                        <SuitabilityBadge score={bestWindowToday.score.overallScore} />
                        <span className="text-slate-500">{fmtDate(bestWindowToday.time)}</span>
                      </div>
                      <div className="h-2 bg-slate-200 dark:bg-slate-700 rounded overflow-hidden">
                        <div className="h-full bg-ocean-600" style={{ width: `${bestWindowToday.score.overallScore}%` }}></div>
                      </div>
                    </div>
                  ) : (
                    <p className="text-slate-500">No suitable window found today.</p>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardTitle>Hourly Timeline</CardTitle>
                <CardContent>
                  <div className="overflow-x-auto pb-4">
                    <table className="w-full min-w-[600px] text-sm">
                      <thead><tr className="border-b border-slate-200 dark:border-slate-700"><th className="text-left py-2 px-3 font-medium text-slate-500">Time</th><th className="text-left py-2 px-3 font-medium text-slate-500">Waves</th><th className="text-left py-2 px-3 font-medium text-slate-500">Period</th><th className="text-left py-2 px-3 font-medium text-slate-500">Wind</th><th className="text-left py-2 px-3 font-medium text-slate-500">Temp</th><th className="text-left py-2 px-3 font-medium text-slate-500">Score</th></tr></thead>
                      <tbody>
                        {scored.slice(0, 24).map((h, i) => {
                          const hr = new Date(h.time).getHours();
                          const isDaylight = hr >= 6 && hr <= 18;
                          const s = h.score;
                          return (
                            <tr key={h.time} className={clsx('border-b border-slate-100 dark:border-slate-800', !isDaylight && 'opacity-50')}>
                              <td className="py-2 px-3 font-mono">{fmtTime(h.time)}</td>
                              <td className="py-2 px-3">{bodyH(h.wave.height)} ({h.wave.height}ft)</td>
                              <td className="py-2 px-3">{h.wave.period}s</td>
                              <td className="py-2 px-3">{windDesc(h.wind.speed, relWind(h.wind.direction, coastAngle))}</td>
                              <td className="py-2 px-3">{fmtTemp(h.waterTemp, unitSys==='metric'?'celsius':'fahrenheit')}</td>
                              <td className="py-2 px-3 font-medium">{s.suitability} ({s.overallScore})</td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>

              <div className="mt-6 flex flex-wrap gap-2">
                <Link href="/forecast"><Button variant="primary"><Waves className="h-4 w-4"/>7-Day Forecast</Button></Link>
                <Link href="/spots"><Button variant="secondary"><MapPin className="h-4 w-4"/>Nearby Spots</Button></Link>
                <Link href="/skill"><Button variant="outline">Take Skill Quiz</Button></Link>
              </div>
            </>
          )}
        </div>
      </section>
    </div>
  );
}