'use client';
import { useUser } from '@/hooks/useUser';
import { Card, CardContent, CardTitle } from '@/components/ui/Card';
import { Badge, LevelBadge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { CheckCircle, Circle, MinusCircle, Target, TrendingUp, Trophy } from 'lucide-react';
import { clsx } from 'clsx';
import { LEVEL_DEFINITIONS } from '@/types';

const skillsByLevel = {
  1: [{id:'paddle',name:'Safe Paddling Technique',cat:'paddling',req:true,desc:'Lie centered, alternate arms, keep feet together',mistakes:['Too far forward/back','Short choppy strokes'],drill:'Paddle 100m without stopping, focus on long strokes'},{id:'popup',name:'Pop-up in Whitewater',cat:'pop-up',req:true,desc:'Chest up, bring knees under, feet shoulder-width',mistakes:['Knees first','Hands too wide','Looking down'],drill:'10 pop-ups on sand, then 10 in whitewater'},{id:'straight',name:'Riding Whitewater Straight',cat:'riding',req:true,desc:'Weight centered, look ahead, subtle adjustments',mistakes:['Leaning back','Stiff knees','Looking at feet'],drill:'Catch 5 whitewater waves, ride straight to shore'},{id:'control',name:'Board Control & Safety',cat:'safety',req:true,desc:'Hold rails, protect head, fall flat',mistakes:['Diving headfirst','Letting go of board'],drill:'Practice falling safely in waist-deep water'}],
  2: [{id:'turn',name:'Turning in Whitewater',cat:'turning',req:true,desc:'Lean rails, look where you want to go',mistakes:['Leaning back','Not committing'],drill:'Figure-8 turns in whitewater'},{id:'speed',name:'Speed Control',cat:'riding',req:true,desc:'Trim forward/back, use arms for balance',mistakes:['Pearling','Stalling'],drill:'Race a friend - control speed without falling'},{id:'paddleout',name:'Paddling Out Through Whitewater',cat:'paddling',req:true,desc:'Turtle roll or punch through, timing sets',mistakes:['Bad timing','Giving up'],drill:'Paddle out 5 times, minimize time in impact zone'},{id:'selection',name:'Wave Selection Basics',cat:'knowledge',req:false,desc:'Identify peaks, avoid closeouts',mistakes:['Taking every wave','Not watching sets'],drill:'Watch 10 waves, predict which will break best'}],
  3: [{id:'green',name:'Catching Green Waves',cat:'riding',req:true,desc:'Paddle early, match speed, pop up at angle',mistakes:['Too late','Straight pop-up'],drill:'Catch 5 green waves, angle takeoff'},{id:'angle',name:'Angling Takeoff',cat:'riding',req:true,desc:'Paddle at 45°, pop up facing down the line',mistakes:['Straight to beach','Over-rotating'],drill:'Draw line in sand, practice angled pops'},{id:'trim',name:'Trimming Down the Line',cat:'riding',req:true,desc:'Weight forward, subtle rail pressure',mistakes:['Stalling out','Racing shoulder'],drill:'Stay in pocket for 10 seconds'},{id:'sets',name:'Reading Sets',cat:'knowledge',req:true,desc:'Watch horizon, count waves, position early',mistakes:['Inside position','Missing the peak'],drill:'Predict 5 set waves before they break'}],
  4: [{id:'duck',name:'Duck Dive / Turtle Roll',cat:'safety',req:true,desc:'Push nose down, knee on tail, come up behind',mistakes:['Too shallow','Late push'],drill:'10 duck dives in a row'},{id:'etiquette',name:'Lineup Etiquette & Priority',cat:'etiquette',req:true,desc:'Closest to peak = priority, don\'t drop in',mistakes:['Dropping in','Snaking','Paddling wide'],drill:'Surf 1 session, zero etiquette violations'},{id:'priority',name:'Wave Priority Decisions',cat:'etiquette',req:true,desc:'Know when to go, when to yield',mistakes:['Hesitation','Greedy'],drill:'Call "yours/mine" on every wave'},{id:'bottom',name:'Bottom Turns',cat:'turning',req:true,desc:'Compress low, drive off rail, extend up',mistakes:['Too high','Not compressed'],drill:'5 linked bottom turns on forehand/backhand'}],
  5: [{id:'cutback',name:'Cutbacks',cat:'turning',req:true,desc:'Top turn back to pocket, rebound',mistakes:['Too early','Losing speed'],drill:'Cutback on every other wave'},{id:'floater',name:'Floaters',cat:'turning',req:false,desc:'Ride over breaking lip, drop back in',mistakes:['Too heavy','Not committing'],drill:'Attempt floater on crumbling sections'},{id:'reentry',name:'Re-entries',cat:'turning',req:false,desc:'Hit lip vertically, redirect down',mistakes:['Not vertical','Losing board'],drill:'Snap off the top on steep waves'},{id:'barrel',name:'Barrel Basics',cat:'riding',req:false,desc:'Stall, tuck, eye on exit',mistakes:['Too deep','Standing tall'],drill:'Practice stalling in hollow waves'}],
};

export default function ProgressPage() {
  const { profile, checklists, updateChecklistProgress, level, setLevel } = useUser();
  const [expanded, setExpanded] = useState<Record<number,boolean>>({});

  const levelSkills = skillsByLevel[level as keyof typeof skillsByLevel] || [];
  const completed = levelSkills.filter(s => checklists[level]?.[s.id] === 'consistent').length;
  const total = levelSkills.filter(s => s.req).length;
  const progress = total > 0 ? Math.round((completed / total) * 100) : 0;

  const toggle = (lvl: number, id: string) => {
    const cur = checklists[lvl]?.[id] || 'not-yet';
    const next = cur === 'not-yet' ? 'sometimes' : cur === 'sometimes' ? 'consistent' : 'not-yet';
    updateChecklistProgress(lvl, id, next);
  };

  return (
    <div className="min-h-screen">
      <section className="section">
        <div className="container max-w-3xl">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
            <div><h1 className="page-title">Progress Tracker</h1><p className="page-subtitle">Track skills, level up, see your growth</p></div>
            <LevelBadge level={level} />
          </div>

          <Card variant="elevated" className="mb-6">
            <CardContent>
              <div className="flex items-center justify-between mb-4">
                <div><p className="text-sm text-slate-500">Level {level} Progress</p><h2 className="text-2xl font-bold">{LEVEL_DEFINITIONS.find(l=>l.level===level)?.name}</h2></div>
                <div className="text-right"><p className="text-4xl font-bold text-ocean-600">{progress}%</p><p className="text-sm text-slate-500">{completed}/{total} required skills</p></div>
              </div>
              <div className="h-3 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden"><div className="h-full bg-ocean-600 rounded-full transition-all" style={{width:`${progress}%`}}/></div>
              {progress === 100 && level < 5 && (
                <div className="mt-4 p-4 bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800 rounded-lg flex items-center gap-3">
                  <Trophy className="h-6 w-6 text-emerald-600"/><div><p className="font-medium text-emerald-800 dark:text-emerald-200">Ready to Level Up!</p><p className="text-sm text-emerald-600">You've completed all required skills for Level {level}</p></div><Button variant="primary" onClick={()=>setLevel((level+1) as 1|2|3|4|5)}>Level Up to {level+1}</Button>
                </div>
              )}
            </CardContent>
          </Card>

          <div className="space-y-4">
            {Object.entries(skillsByLevel).map(([lvl, skills]) => {
              const lvlNum = Number(lvl);
              const isCurrent = lvlNum === level;
              const lvlCompleted = skills.filter(s => checklists[lvlNum]?.[s.id] === 'consistent').length;
              const lvlTotal = skills.filter(s => s.req).length;
              return (
                <Card key={lvl} variant={isCurrent ? 'elevated' : 'outlined'} className={clsx(isCurrent && 'ring-2 ring-ocean-500')}>
                  <CardContent>
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3"><LevelBadge level={lvlNum}/><div><p className="font-medium">{LEVEL_DEFINITIONS.find(l=>l.level===lvlNum)?.name}</p><p className="text-sm text-slate-500">{lvlCompleted}/{lvlTotal} required complete</p></div></div>
                      <Button variant="ghost" size="sm" onClick={()=>setExpanded(prev=>({...prev,[lvlNum]:!prev[lvlNum]}))}>{expanded[lvlNum]?<ChevronUp className="h-4 w-4"/>:<ChevronDown className="h-4 w-4"/>}</Button>
                    </div>
                    {expanded[lvlNum] && (
                      <div className="space-y-3">
                        {skills.map(s => (
                          <div key={s.id} className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
                            <div className="flex items-start justify-between gap-4">
                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-1"><h4 className="font-medium">{s.name}</h4>{s.req&&<Badge variant="info" size="sm">Required</Badge>}</div>
                                <p className="text-sm text-slate-600 dark:text-slate-400">{s.desc}</p>
                                <div className="mt-2 space-y-1 text-xs text-slate-500">
                                  <p><strong>Mistakes:</strong> {s.mistakes.join(', ')}</p>
                                  <p><strong>Drill:</strong> {s.drill}</p>
                                </div>
                              </div>
                              <div className="flex items-center gap-2">
                                {['not-yet','sometimes','consistent'].map(st => (
                                  <button key={st} onClick={()=>toggle(lvlNum,s.id)} className={clsx('w-8 h-8 rounded border-2 font-medium transition',checklists[lvlNum]?.[s.id]===st?'bg-ocean-600 border-ocean-600 text-white':'bg-white dark:bg-slate-800 border-slate-300 dark:border-slate-600')}>{st==='not-yet'?<Circle className="h-4 w-4"/>:st==='sometimes'?<MinusCircle className="h-4 w-4"/>:<CheckCircle className="h-4 w-4"/>}</button>
                                ))}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {profile?.sessionLog.length && (
            <Card className="mt-6">
              <CardTitle>Recent Sessions</CardTitle>
              <CardContent>
                <div className="space-y-2 max-h-64 overflow-auto">
                  {profile.sessionLog.slice(0,5).map(s=>(
                    <div key={s.id} className="flex items-center justify-between p-3 rounded-lg bg-slate-50 dark:bg-slate-800/50"><div><p className="font-medium">{s.spotName}</p><p className="text-sm text-slate-500">{s.date} • {s.durationMinutes}min • {s.rating}/5</p></div><TrendingUp className="h-5 w-5 text-ocean-600"/></div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </section>
    </div>
  );
}