'use client';
import { Card, CardContent, CardTitle } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { AlertTriangle, CheckCircle, Waves, Sun, Snowflake, UserCheck, Shield, Info, Heart, LifeBuoy } from 'lucide-react';
import { clsx } from 'clsx';

const topics = [
  {id:'rip',title:'Rip Currents',icon:Waves,color:'red',sections:[{title:'What is a rip?',content:'A strong, narrow current flowing away from shore. Can move faster than an Olympic swimmer.'},{title:'How to spot one',content:'Darker water, fewer breaking waves, choppy surface, debris moving seaward, break in wave pattern.'},{title:'If caught in a rip',content:'1. Stay calm - don\'t fight it. 2. Float/tread water. 3. Signal for help (wave one arm). 4. Swim PARALLEL to shore until out of current. 5. Then swim back at an angle.'},{title:'Prevention',content:'Swim near lifeguards. Check conditions. Never surf alone. Know your limits.'}]},
  {id:'lineup',title:'Reading the Lineup',icon:Shield,color:'blue',sections:[{title:'Identify the peak',content:'Where the wave breaks first - this is the takeoff zone.'},{title:'Channels',content:'Deeper areas where waves don\'t break - use these to paddle out.'},{title:'Impact zone',content:'Where waves break hardest - avoid sitting here.'},{title:'Shoulder',content:'The unbroken part of the wave - where you want to ride.'}]},
  {id:'sun',title:'Sun Safety',icon:Sun,color:'amber',sections:[{title:'UV reflection',content:'Water reflects UV, doubling exposure. Even on cloudy days.'},{title:'Protection',content:'Reef-safe SPF 30+ sunscreen. Reapply every 2 hours. Wear UPF rash guard. Hat when not surfing.'},{title:'Timing',content:'UV strongest 10am-4pm. Early/late sessions safer.'}]},
  {id:'cold',title:'Cold Water Safety',icon:Snowflake,color:'blue',sections:[{title:'Cold shock',content:'Gasping, hyperventilation, heart strain in water <60°F. Enter slowly.'},{title:'Wetsuit guide',content:'65-70°F: 2mm spring. 60-65°F: 3/2mm full. 55-60°F: 4/3mm + boots. <55°F: 5/4mm + hood + gloves + boots.'},{title:'Hypothermia signs',content:'Shivering, confusion, slurred speech, clumsiness. Get warm immediately.'}]},
  {id:'buddy',title:'Never Surf Alone',icon:UserCheck,color:'green',sections:[{title:'Why it matters',content:'No one to help if you\'re injured, held down, or caught in a rip.'},{title:'Buddy system',content:'Surf with a friend. Watch each other. Agree on check-in times.'},{title:'Tell someone',content:'Always tell someone: where, when, how long. Text when you\'re out.'}]},
  {id:'skip',title:'When to Skip',icon=AlertTriangle,color='red',sections:[{title:'Red flags',content:'Double overhead+, storm surf, lightning, contaminated water, no exit point.'},{title:'Personal limits',content:'Fatigued, sick, hungover, new board you can\'t control, conditions above your level.'},{title:'Trust your gut',content:'If it feels wrong, it probably is. The ocean will be there tomorrow.'}]},
];

export default function SafetyPage() {
  const [open, setOpen] = useState<string|null>(null);
  return (
    <div className="min-h-screen">
      <section className="section">
        <div className="container max-w-3xl">
          <h1 className="page-title">Safety Center</h1>
          <p className="page-subtitle">Essential knowledge for staying safe in the ocean</p>

          <Card variant="outlined" className="mb-8 border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-900/10">
            <CardContent className="flex items-start gap-3"><Info className="h-5 w-5 text-amber-600 mt-0.5"/><div><h3 className="font-medium text-amber-800 dark:text-amber-200 mb-1">Disclaimer</h3><p className="text-sm text-amber-700 dark:text-amber-300">Forecasts are estimates. Always check local lifeguards, signage, and conditions before entering. You are responsible for your own safety.</p></div></CardContent>
          </Card>

          <div className="space-y-4">
            {topics.map(t => (
              <Card key={t.id} variant="elevated">
                <CardContent>
                  <button onClick={()=>setOpen(o=>o===t.id?null:t.id)} className="w-full flex items-center justify-between">
                    <div className="flex items-center gap-3"><span className={clsx('p-2 rounded-lg',t.color==='red'&&'bg-red-100 dark:bg-red-900/30',t.color==='blue'&&'bg-blue-100 dark:bg-blue-900/30',t.color==='amber'&&'bg-amber-100 dark:bg-amber-900/30',t.color==='green'&&'bg-emerald-100 dark:bg-emerald-900/30')}>
                      <t.icon className={clsx('h-5 w-5',t.color==='red'&&'text-red-600',t.color==='blue'&&'text-blue-600',t.color==='amber'&&'text-amber-600',t.color==='green'&&'text-emerald-600')} />
                    </span><h3 className="font-semibold text-slate-900 dark:text-white">{t.title}</h3></div>
                    {open===t.id?<ChevronUp className="h-5 w-5 text-slate-500"/>:<ChevronDown className="h-5 w-5 text-slate-500"/>}
                  </button>
                  {open===t.id && (
                    <div className="mt-4 space-y-4 border-t border-slate-200 dark:border-slate-700 pt-4">
                      {t.sections.map((s,i)=>(<div key={i}><h4 className="font-medium text-slate-900 dark:text-white mb-1">{s.title}</h4><p className="text-sm text-slate-600 dark:text-slate-400">{s.content}</p></div>))}
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>

          <Card variant="elevated" className="mt-8">
            <CardTitle>Pre-Session Safety Checklist</CardTitle>
            <CardContent>
              <div className="grid gap-3 md:grid-cols-2">
                {[
                  'Checked forecast & tides','Told someone my plan','Buddy confirmed or lifeguard on duty','Board & leash in good condition','Wetsuit appropriate for temp','Sunscreen applied (reef-safe)','Know the rip current escape','Identified exit points','Hydrated & not fatigued','Conditions match my level'
                ].map((item,i)=>(<label key={i} className="flex items-center gap-2 cursor-pointer"><input type="checkbox" className="w-4 h-4 rounded border-slate-300 text-ocean-600"/><span className="text-sm text-slate-700 dark:text-slate-300">{item}</span></label>))}
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}