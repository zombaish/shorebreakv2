'use client';
import { useState } from 'react';
import { useUser } from '@/hooks/useUser';
import { Card, CardContent, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Select } from '@/components/ui/Select';
import { Badge, LevelBadge } from '@/components/ui/Badge';
import { Brain, Target, CheckCircle, ChevronDown, ChevronUp, RotateCcw } from 'lucide-react';
import { clsx } from 'clsx';
import type { SkillQuizAnswers, SkillQuizResult } from '@/types';
import { LEVEL_DEFINITIONS } from '@/types';

const questions = [
  {id:'swim',label:'How comfortable are you swimming in the ocean?',type:'scale' as const,options:[{v:1,l:'Not comfortable'},{v:2,l:'Slightly'},{v:3,l:'Moderately'},{v:4,l:'Very'},{v:5,l:'Extremely'}]},
  {id:'times',label:'How many times have you surfed?',type:'number' as const,placeholder:'0'},
  {id:'paddle',label:'Can you paddle and pop up on a foam board?',type:'boolean' as const},
  {id:'chest',label:'Are you comfortable in chest-high waves?',type:'boolean' as const},
  {id:'etiquette',label:'How well do you know surf etiquette?',type:'scale' as const,options:[{v:1,l:'Not at all'},{v:2,l:'A little'},{v:3,l:'Some'},{v:4,l:'Well'},{v:5,l:'Expert'}]},
  {id:'fitness',label:'How would you rate your fitness level?',type:'scale' as const,options:[{v:1,l:'Low'},{v:2,l:'Below avg'},{v:3,l:'Average'},{v:4,l:'Above avg'},{v:5,l:'High'}]},
  {id:'age',label:'Age range',type:'select' as const,options:[{v:'under-18',l:'Under 18'},{v:'18-25',l:'18-25'},{v:'26-35',l:'26-35'},{v:'36-50',l:'36-50'},{v:'50+',l:'50+'}]},
  {id:'board',label:'What board do you own?',type:'select' as const,options:[{v:'none',l:'None (renting)'},{v:'foam',l:'Foam board'},{v:'funboard',l:'Funboard'},{v:'fish',l:'Fish'},{v:'shortboard',l:'Shortboard'},{v:'longboard',l:'Longboard'}]},
];

export default function SkillPage() {
  const { profile, takeQuiz, applyQuizResult, level, setLevel } = useUser();
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<Partial<SkillQuizAnswers>>({});
  const [result, setResult] = useState<SkillQuizResult|null>(null);
  const [showResult, setShowResult] = useState(false);

  const handleAnswer = (id: string, value: any) => { setAnswers(prev=>({...prev,[id]:value})); if(step<questions.length-1)setTimeout(()=>setStep(s=>s+1),300); else { const r = takeQuiz(answers as SkillQuizAnswers); setResult(r); setShowResult(true); } };
  const retake = () => { setStep(0); setAnswers({}); setResult(null); setShowResult(false); };
  const apply = () => { if(result) applyQuizResult(result); };

  const current = questions[step];
  const progress = ((step+1)/questions.length)*100;

  return (
    <div className="min-h-screen">
      <section className="section">
        <div className="container max-w-2xl">
          <div className="mb-8"><h1 className="page-title">Skill Assessment</h1><p className="page-subtitle">Answer 8 questions to find your surf level</p></div>

          <div className="mb-6 h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden"><div className="h-full bg-ocean-600 transition-all duration-300" style={{width:`${progress}%`}}/></div>
          <p className="text-sm text-slate-500 mb-6 text-center">Question {step+1} of {questions.length}</p>

          {showResult && result && (
            <Card variant="elevated">
              <CardContent className="text-center py-8">
                <div className="w-24 h-24 mx-auto mb-4 rounded-full bg-ocean-100 dark:bg-ocean-900/30 flex items-center justify-center text-4xl font-bold text-ocean-700 dark:text-ocean-300">Level {result.level}</div>
                <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">{LEVEL_DEFINITIONS.find(l=>l.level===result.level)?.name}</h2>
                <p className="text-slate-600 dark:text-slate-400 mb-6 max-w-md mx-auto">{LEVEL_DEFINITIONS.find(l=>l.level===result.level)?.description}</p>
                <div className="space-y-2 text-left max-w-md mx-auto mb-6">{result.reasoning.map((r,i)=>(<div key={i} className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400"><CheckCircle className="h-4 w-4 text-emerald-600"/>{r}</div>))}</div>
                <div className="flex gap-4 justify-center"><Button variant="primary" onClick={apply}><Target className="h-4 w-4"/>Set as My Level</Button><Button variant="secondary" onClick={retake}><RotateCcw className="h-4 w-4"/>Retake Quiz</Button></div>
              </CardContent>
            </Card>
          )}

          {!showResult && (
            <Card variant="elevated">
              <CardContent className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">{current.label}</label>
                  {current.type==='scale' && (
                    <div className="grid grid-cols-5 gap-2">
                      {current.options!.map(o=>(<button key={o.v} onClick={()=>handleAnswer(current.id,o.v)} className={clsx('py-3 rounded-lg font-medium transition',answers[current.id]===o.v?'bg-ocean-600 text-white':'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700')}>{o.l}</button>))}
                    </div>
                  )}
                  {current.type==='number' && <Input type="number" placeholder={current.placeholder} value={answers[current.id]||''} onChange={e=>handleAnswer(current.id,Number(e.target.value))} />}
                  {current.type==='boolean' && (
                    <div className="grid grid-cols-2 gap-3">
                      <button onClick={()=>handleAnswer(current.id,true)} className={clsx('py-4 rounded-lg font-medium border-2',answers[current.id]===true?'border-ocean-600 bg-ocean-50 text-ocean-700 dark:bg-ocean-900/20':'border-slate-300 dark:border-slate-600 hover:bg-slate-50')}>Yes</button>
                      <button onClick={()=>handleAnswer(current.id,false)} className={clsx('py-4 rounded-lg font-medium border-2',answers[current.id]===false?'border-ocean-600 bg-ocean-50 text-ocean-700 dark:bg-ocean-900/20':'border-slate-300 dark:border-slate-600 hover:bg-slate-50')}>No</button>
                    </div>
                  )}
                  {current.type==='select' && (
                    <Select value={answers[current.id]||''} onChange={e=>handleAnswer(current.id,e.target.value)} options={current.options!.map(o=>({value:o.v,label:o.l}))} placeholder="Select..." />
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {!showResult && profile && (
            <Card className="mt-6">
              <CardTitle>Your Current Level</CardTitle>
              <CardContent><LevelBadge level={level} /></CardContent>
            </Card>
          )}
        </div>
      </section>
    </div>
  );
}