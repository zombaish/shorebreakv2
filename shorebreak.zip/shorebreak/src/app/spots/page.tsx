'use client';
import { useState } from 'react';
import { useForecast } from '@/hooks/useForecast';
import { useUser } from '@/hooks/useUser';
import { Card, CardContent, CardTitle } from '@/components/ui/Card';
import { Badge, SuitabilityBadge, HazardBadge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Select } from '@/components/ui/Select';
import { MapPin, Navigation, Clock, AlertTriangle, Filter, X, Map, List } from 'lucide-react';
import { clsx } from 'clsx';
import { fmtDist, fmtTime, bodyH, windDesc, relWind } from '@/lib/utils/units';
import type { Spot } from '@/types';

export default function SpotsPage() {
  const { profile } = useUser();
  const level = profile?.level || 1;
  const [lat, setLat] = useState(37.7749);
  const [lon, setLon] = useState(-122.4194);
  const [radius, setRadius] = useState(50);
  const [maxDist, setMaxDist] = useState(50);
  const [minScore, setMinScore] = useState(0);
  const [waveType, setWaveType] = useState<'all'|'beach'|'point'|'reef'>('all');
  const [view, setView] = useState<'list'|'map'>('list');
  const { spots, loading, error, refetch } = useForecast(lat, lon, level);

  const filtered = spots.filter(s => s.distanceKm <= maxDist && s.suitabilityScore >= minScore && (waveType==='all'||s.waveType===waveType));

  if (loading && !spots.length) return <div className="section container"><div className="flex h-64 items-center justify-center"><div className="animate-spin rounded-full h-12 w-12 border-4 border-ocean-600 border-t-transparent"/></div></div>;

  return (
    <div className="min-h-screen">
      <section className="section">
        <div className="container">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
            <div><h1 className="page-title">Spot Finder</h1><p className="page-subtitle">Discover beginner-friendly breaks near you</p></div>
            <div className="flex flex-wrap gap-2">
              <Button variant="outline" onClick={refetch}><Filter className="h-4 w-4"/> Filters</Button>
              <Button variant="ghost" onClick={()=>setView(v=>v==='list'?'map':'list')}>{view==='list'?<Map className="h-4 w-4"/>:<List className="h-4 w-4"/>}</Button>
            </div>
          </div>

          <Card className="mb-6">
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-3">
                <Input label="Max Distance (km)" type="number" value={maxDist} onChange={e=>setMaxDist(Number(e.target.value))} min={1} max={200} />
                <Select value={waveType} onChange={e=>setWaveType(e.target.value as 'all'|'beach'|'point'|'reef')} options={[{value:'all',label:'All Types'},{value:'beach',label:'Beach Break'},{value:'point',label:'Point Break'},{value:'reef',label:'Reef Break'}]} placeholder="Wave Type" />
                <Select value={level} onChange={e=>setMinScore(Number(e.target.value))} options={[{value:1,label:'Level 1+'},{value:2,label:'Level 2+'},{value:3,label:'Level 3+'},{value:4,label:'Level 4+'},{value:5,label:'Level 5+'}]} placeholder="Min Level" />
              </div>
              <div className="flex items-center gap-4 text-sm text-slate-500">
                <span>{filtered.length} of {spots.length} spots match</span>
                <span>•</span>
                <span>Showing within {maxDist}km</span>
              </div>
            </CardContent>
          </Card>

          {error && <div className="mb-6 p-4 rounded-lg bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-800 dark:text-red-200">{error}</div>}

          {view === 'list' ? (
            <div className="space-y-4">
              {filtered.map(spot => (
                <Card key={spot.id} variant="elevated" className="overflow-hidden">
                  <CardContent className="flex flex-col md:flex-row md:items-center gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-4 mb-2">
                        <div>
                          <h3 className="font-semibold text-slate-900 dark:text-white">{spot.name}</h3>
                          <p className="text-sm text-slate-500 flex items-center gap-1"><MapPin className="h-3.5 w-3.5"/>{fmtDist(spot.distanceKm)} • {spot.driveTimeMin} min drive</p>
                        </div>
                        <SuitabilityBadge score={spot.suitabilityScore} />
                      </div>
                      <div className="flex flex-wrap gap-2 text-sm text-slate-600 dark:text-slate-400">
                        <span className="flex items-center gap-1"><Waves className="h-3.5 w-3.5"/>{spot.waveType} • {spot.orientation}</span>
                        <span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5"/>{spot.bestWindow?`Best: ${fmtTime(spot.bestWindow.start)}`:'No good window'}</span>
                      </div>
                      {spot.hazards.length > 0 && (
                        <div className="mt-2 flex flex-wrap gap-1.5">{spot.hazards.map(h=><HazardBadge key={h.type} type={h.type}/>)}</div>
                      )}
                    </div>
                    <div className="flex items-center gap-2 md:ml-4">
                      <Button variant="primary" size="sm" className="whitespace-nowrap"><Navigation className="h-3.5 w-3.5"/>Directions</Button>
                      <Button variant="ghost" size="sm"><AlertTriangle className="h-3.5 w-3.5"/>Details</Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
              {filtered.length === 0 && (
                <Card><CardContent className="text-center py-12 text-slate-500">No spots match your filters. Try expanding your search radius or lowering requirements.</CardContent></Card>
              )}
            </div>
          ) : (
            <Card><CardContent className="h-[500px] bg-slate-100 dark:bg-slate-800 rounded-lg flex items-center justify-center text-slate-500">Map view coming soon - uses Leaflet + OpenStreetMap</CardContent></Card>
          )}
        </div>
      </section>
    </div>
  );
}