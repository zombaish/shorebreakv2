'use client';
import { HTMLAttributes, forwardRef } from 'react';
import { clsx } from 'clsx';
interface Props extends HTMLAttributes<HTMLSpanElement> { variant?: 'default'|'success'|'warning'|'danger'|'info'; size?: 'sm'|'md'|'lg'; dot?: boolean; }
export const Badge = forwardRef<HTMLSpanElement,Props>(({className,variant='default',size='md',dot,children,...props},ref)=>{
  const v={default:'bg-slate-100 text-slate-700 dark:bg-slate-700 dark:text-slate-200',success:'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400',warning:'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400',danger:'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400',info:'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400'};
  const s={sm:'px-2 py-0.5 text-xs',md:'px-2.5 py-1 text-sm',lg:'px-3 py-1.5 text-base'};
  return <span ref={ref} className={clsx('inline-flex items-center gap-1.5 font-medium rounded-full',v[variant],s[size],className)} {...props}>{dot&&<span className={clsx('w-1.5 h-1.5 rounded-full',variant==='success'&&'bg-emerald-500',variant==='warning'&&'bg-amber-500',variant==='danger'&&'bg-red-500',variant==='info'&&'bg-blue-500',variant==='default'&&'bg-slate-500')}/>}{children}</span>;
});
Badge.displayName='Badge';
export function SuitabilityBadge({score}:{score:number}){if(score>=70)return<Badge variant="success" dot>Good</Badge>;if(score>=40)return<Badge variant="warning" dot>Okay</Badge>;return<Badge variant="danger" dot>Skip</Badge>;}
export function LevelBadge({level}:{level:number}){const c={1:'success',2:'success',3:'warning',4:'warning',5:'danger'};const n={1:'Level 1',2:'Level 2',3:'Level 3',4:'Level 4',5:'Level 5'};return<Badge variant={c[level]||'default'} size="md">{n[level]}</Badge>;}
export function HazardBadge({type}:{type:string}){const v:{[k:string]:'danger'|'warning'|'info'}={BIG_PERIOD_JUMP:'danger',STRONG_ONSHORE:'warning',RIP_RISK:'danger',COLD_WATER:'warning',LOW_DAYLIGHT:'info',HIGH_UV:'warning'};return<Badge variant={v[type]||'default'} size="sm">{type.replace(/_/g,' ')}</Badge>;}