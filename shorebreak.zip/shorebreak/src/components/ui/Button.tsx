'use client';
import { ButtonHTMLAttributes, forwardRef } from 'react';
import { clsx } from 'clsx';
interface Props extends ButtonHTMLAttributes<HTMLButtonElement> { variant?: 'primary'|'secondary'|'outline'|'ghost'|'danger'; size?: 'sm'|'md'|'lg'; loading?: boolean; fullWidth?: boolean; }
export const Button = forwardRef<HTMLButtonElement,Props>(({className,variant='primary',size='md',loading,fullWidth,disabled,children,...props},ref)=>{
  const base='inline-flex items-center justify-center font-medium rounded-lg transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed';
  const vars={primary:'bg-ocean-600 text-white hover:bg-ocean-700 focus:ring-ocean-500',secondary:'bg-slate-100 text-slate-900 hover:bg-slate-200 focus:ring-slate-400 dark:bg-slate-700 dark:text-slate-100 dark:hover:bg-slate-600',outline:'border-2 border-ocean-600 text-ocean-600 hover:bg-ocean-50 focus:ring-ocean-500 dark:border-ocean-400 dark:text-ocean-400 dark:hover:bg-ocean-900/20',ghost:'text-ocean-600 hover:bg-ocean-50 focus:ring-ocean-500 dark:text-ocean-400 dark:hover:bg-ocean-900/20',danger:'bg-red-600 text-white hover:bg-red-700 focus:ring-red-500'};
  const sz={sm:'px-3 py-1.5 text-sm gap-1.5',md:'px-4 py-2 text-base gap-2',lg:'px-6 py-3 text-lg gap-2.5'};
  return <button ref={ref} className={clsx(base,vars[variant],sz[size],fullWidth&&'w-full',className)} disabled={disabled||loading} {...props}>{loading&&<svg className="animate-spin h-4 w-4" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3" fill="none"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"/></svg>}{children}</button>;
});
Button.displayName='Button';