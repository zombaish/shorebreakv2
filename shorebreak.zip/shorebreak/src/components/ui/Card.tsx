'use client';
import { HTMLAttributes, forwardRef } from 'react';
import { clsx } from 'clsx';
interface Props extends HTMLAttributes<HTMLDivElement> { variant?: 'default'|'elevated'|'outlined'; padding?: 'none'|'sm'|'md'|'lg'; hover?: boolean; }
export const Card = forwardRef<HTMLDivElement,Props>(({className,variant='default',padding='md',hover,children,...props},ref)=>{
  const v={default:'bg-white dark:bg-slate-800',elevated:'bg-white dark:bg-slate-800 shadow-lg',outlined:'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700'};
  const p={none:'',sm:'p-3',md:'p-4 md:p-6',lg:'p-6 md:p-8'};
  return <div ref={ref} className={clsx('rounded-xl transition-shadow',v[variant],p[padding],hover&&'hover:shadow-xl cursor-pointer',className)} {...props}>{children}</div>;
});
Card.displayName='Card';
export const CardHeader=forwardRef<HTMLDivElement,HTMLAttributes<HTMLDivElement>>(({className,children,...props},ref)=><div ref={ref} className={clsx('mb-4',className)} {...props}>{children}</div>);
export const CardTitle=forwardRef<HTMLHeadingElement,HTMLAttributes<HTMLHeadingElement>>(({className,children,...props},ref)=><h3 ref={ref} className={clsx('text-lg font-semibold text-slate-900 dark:text-white',className)} {...props}>{children}</h3>);
export const CardContent=forwardRef<HTMLDivElement,HTMLAttributes<HTMLDivElement>>(({className,children,...props},ref)=><div ref={ref} className={clsx(className)} {...props}>{children}</div>);