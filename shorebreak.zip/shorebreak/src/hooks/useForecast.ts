'use client';
import { useState, useEffect, useCallback } from 'react';
import { fetchConditions, searchLocations } from '@/lib/api/open-meteo';
import { fetchCoastlineSpots, rankSpots } from '@/lib/api/overpass';
import { scoreConditions, toScoringInput } from '@/lib/scoring';
import { fetchCache } from '@/lib/storage/cache';
import type { HourlyForecast, DailyForecast, CurrentConditions, Spot, ScoringInput } from '@/types';

export function useForecast(lat: number, lon: number, level: number, coast=270) {
  const [state, setState] = useState({ current: null as CurrentConditions|null, hourly: [] as HourlyForecast[], daily: [] as DailyForecast[], scored: [] as (HourlyForecast&{score:ReturnType<typeof scoreConditions>})[], spots: [] as Spot[], loading: true, error: null as string|null, updated: null as Date|null });
  const load = useCallback(async()=>{ setState(s=>({...s,loading:true,error:null})); try{ const key=`fc-${lat.toFixed(2)}-${lon.toFixed(2)}`; const data=await fetchCache(key,()=>fetchConditions(lat,lon)); const scored=data.hourly.map((h,i)=>{ const inp=toScoringInput(h,coast,i); return {...h,score:scoreConditions(inp,level,data.hourly.map((hh,ii)=>toScoringInput(hh,coast,ii)))}; }); let spots: Spot[]=[]; try{ const raw=await fetchCoastlineSpots(lat,lon,50); spots=await rankSpots(raw,data.hourly.map((h,i)=>toScoringInput(h,coast,i)),level); }catch{} setState({current:data.current,hourly:data.hourly,daily:data.daily,scored,spots,loading:false,error:null,updated:new Date()}); }catch(e){ setState(s=>({...s,loading:false,error:e instanceof Error?e.message:'Failed to load'})); }},[lat,lon,level,coast]);
  useEffect(()=>{load();},[load]);
  const best = state.scored.filter(h=>{const hr=new Date(h.time).getHours();return hr>=6&&hr<=18;}).reduce((b,c)=>c.score.overallScore>b.score.overallScore?c:b, state.scored[0]);
  return {...state,refetch:load,bestWindowToday:best||null};
}
export function useSearch() { const [res,setRes]=useState<Array<{name:string;lat:number;lon:number;country:string}>>([]); const [ld,setLd]=useState(false); const [er,setEr]=useState<string|null>(null);
  const search=useCallback(async(q:string)=>{ if(q.length<2){setRes([]);return} setLd(true);setEr(null); try{setRes(await searchLocations(q));}catch(e){setEr(e instanceof Error?e.message:'Search failed');setRes([]);}finally{setLd(false);} },[]);
  return {results:res,loading:ld,error:er,search};
}
export function useGeo() { const [loc,setLoc]=useState<{lat:number;lon:number}|null>(null); const [er,setEr]=useState<string|null>(null);
  const req=useCallback(()=>{ if(!navigator.geolocation){setEr('Geolocation not supported');return} navigator.geolocation.getCurrentPosition(p=>setLoc({lat:p.coords.latitude,lon:p.coords.longitude}),e=>setEr(e.message),{enableHighAccuracy:true,timeout:10000}); },[]);
  return {location:loc,error:er,request:req};
}