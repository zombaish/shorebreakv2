'use client';
import { useState, useEffect, useCallback } from 'react';
type Theme = 'light'|'dark'|'system';
export function useTheme(){
  const [t,setT]=useState<Theme>(()=>{if(typeof window==='undefined')return'system';return(localStorage.getItem('sb_theme')as Theme)||'system'});
  const [rt,setRt]=useState<'light'|'dark'>('light');
  useEffect(()=>{const r=document.documentElement;const st=window.matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light';const res=t==='system'?st:t;setRt(res);r.classList.remove('light','dark');r.classList.add(res);localStorage.setItem('sb_theme',t);},[t]);
  useEffect(()=>{const m=window.matchMedia('(prefers-color-scheme: dark)');const h=()=>{if(t==='system'){const s=m.matches?'dark':'light';setRt(s);document.documentElement.classList.remove('light','dark');document.documentElement.classList.add(s);}};m.addEventListener('change',h);return()=>m.removeEventListener('change',h);},[t]);
  const tog=useCallback(()=>setT(p=>p==='light'?'dark':p==='dark'?'system':'light'),[]);
  const set=useCallback((x:Theme)=>setT(x),[]);
  return{theme:t,resolved:rt,toggle:tog,setTheme:set};}