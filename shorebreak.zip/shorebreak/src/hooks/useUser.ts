'use client';
import { useState, useEffect, useCallback } from 'react';
import { getProfile, save, setLevel, addFav, remFav, setChecklist, addSession, updSettings, quizResult, createDefault, clearData } from '@/lib/storage/user';
import type { UserProfile, SurfLevel, SkillQuizAnswers, SkillQuizResult, SessionEntry, FavoriteSpot } from '@/types';

export function useUser() {
  const [p,setP]=useState<UserProfile|null>(null); const [ld,setLd]=useState(true);
  useEffect(()=>{ setP(getProfile()||createDefault()); setLd(false); },[]);
  const refresh=useCallback(()=>setP(getProfile()||createDefault()),[]);
  const lvl=useCallback((l:SurfLevel)=>{setP(setLevel(l));},[]);
  const af=useCallback((s:FavoriteSpot)=>{setP(addFav(s));},[]);
  const rf=useCallback((id:string)=>{setP(remFav(id));},[]);
  const uc=useCallback((lvl:number,sk:string,v:'not-yet'|'sometimes'|'consistent')=>{setP(setChecklist(lvl,sk,v));},[]);
  const as=useCallback((e:Omit<SessionEntry,'id'>)=>{setP(addSession(e));},[]);
  const us=useCallback((s:Partial<UserProfile['settings']>)=>{setP(updSettings(s));},[]);
  const qr=useCallback((a:SkillQuizAnswers)=>quizResult(a),[]);
  const aqr=useCallback((r:SkillQuizResult)=>{lvl(r.level);},[lvl]);
  const rd=useCallback(()=>{clearData();setP(createDefault());},[]);
  return {profile:p,loading:ld,refresh,level:p?.level||1,setLevel:lvl,favorites:p?.favorites||[],addFav:af,removeFav:rf,checklists:p?.checklists||{},updateChecklist:uc,sessionLog:p?.sessionLog||[],addSession:as,settings:p?.settings,updateSettings:us,takeQuiz:qr,applyQuizResult:aqr,resetData:rd};
}
export function useLevel(){const{p,setLevel,level}=useUser();const info={1:{name:'Foam-board Basics',max:2,color:'green'},2:{name:'Whitewater Riding',max:3,color:'lime'},3:{name:'Green Waves',max:4,color:'yellow'},4:{name:'Lineup Surfing',max:6,color:'orange'},5:{name:'Intermediate',max:8,color:'red'}};return{level,info:info[level],setLevel,canUp:level<5,canDown:level>1};}