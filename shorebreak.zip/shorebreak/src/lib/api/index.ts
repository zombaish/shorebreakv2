export { fetchConditions, searchLocations } from './open-meteo';
export { fetchCoastlineSpots, rankSpots } from './overpass';