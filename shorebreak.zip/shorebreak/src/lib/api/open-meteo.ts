import type { ConditionsResponse, HourlyForecast, DailyForecast, CurrentConditions, WaveData, WindData } from '@/types';

const MARINE = 'https://marine-api.open-meteo.com/v1/marine';
const WEATHER = 'https://api.open-meteo.com/v1/forecast';
const GEOCODE = 'https://geocoding-api.open-meteo.com/v1/search';

function m2ft(m: number) { return Math.round(m * 3.28084 * 10) / 10; }
function c2f(c: number) { return Math.round(c * 9/5 + 32); }
function cardDir(d: number) { const a = ['N','NNE','NE','ENE','E','ESE','SE','SSE','S','SSW','SW','WSW','W','WNW','NW','NNW']; return a[Math.round(d/22.5)%16]; }
function domDir(arr: number[]) { const s = arr.reduce((a,b)=>a+Math.sin(b*Math.PI/180),0), c = arr.reduce((a,b)=>a+Math.cos(b*Math.PI/180),0); let d = Math.atan2(s,c)*180/Math.PI; if(d<0)d+=360; return Math.round(d); }

export async function fetchConditions(lat: number, lon: number): Promise<ConditionsResponse> {
  const [mar, wea] = await Promise.all([
    fetch(`${MARINE}?latitude=${lat}&longitude=${lon}&current=wave_height,wave_direction,wave_period,wind_wave_height,wind_wave_direction,wind_wave_period,swell_wave_height,swell_wave_direction,swell_wave_period,sea_surface_temperature&hourly=wave_height,wave_direction,wave_period,wind_wave_height,wind_wave_direction,wind_wave_period,swell_wave_height,swell_wave_direction,swell_wave_period,sea_surface_temperature&timezone=auto&forecast_days=7`).then(r=>r.json()),
    fetch(`${WEATHER}?latitude=${lat}&longitude=${lon}&current=temperature_2m,wind_speed_10m,wind_direction_10m,wind_gusts_10m&hourly=temperature_2m,wind_speed_10m,wind_direction_10m,wind_gusts_10m,uv_index,uv_index_clear_sky&daily=sunrise,sunset,uv_index_max&timezone=auto&forecast_days=7&wind_speed_unit=kn&temperature_unit=fahrenheit`).then(r=>r.json())
  ]);
  const cur = { wave: { height: m2ft(mar.current.wave_height), period: mar.current.wave_period, direction: mar.current.wave_direction, directionCardinal: cardDir(mar.current.wave_direction) }, wind: { speed: wea.current.wind_speed_10m, direction: wea.current.wind_direction_10m, directionCardinal: cardDir(wea.current.wind_direction_10m), gusts: wea.current.wind_gusts_10m }, waterTemp: c2f(mar.current.sea_surface_temperature), airTemp: wea.current.temperature_2m, timestamp: mar.current.time };
  const hourly: HourlyForecast[] = mar.hourly.time.map((t:string,i)=>({ time: t, wave: { height: m2ft(mar.hourly.wave_height[i]), period: mar.hourly.wave_period[i], direction: mar.hourly.wave_direction[i], directionCardinal: cardDir(mar.hourly.wave_direction[i]) }, wind: { speed: wea.hourly.wind_speed_10m[i], direction: wea.hourly.wind_direction_10m[i], directionCardinal: cardDir(wea.hourly.wind_direction_10m[i]), gusts: wea.hourly.wind_gusts_10m[i] }, waterTemp: c2f(mar.hourly.sea_surface_temperature[i]), airTemp: wea.hourly.temperature_2m[i], uvIndex: wea.hourly.uv_index[i] }));
  const daily: DailyForecast[] = wea.daily.time.map((d:string,i)=>{ const dayHours = hourly.filter(h=>h.time.startsWith(d)); const hs = dayHours.map(h=>h.wave.height), ps = dayHours.map(h=>h.wave.period), ds = dayHours.map(h=>h.wave.direction); return { date: d, maxWaveHeight: Math.max(...hs), minWaveHeight: Math.min(...hs), dominantPeriod: Math.round(ps.reduce((a,b)=>a+b,0)/ps.length), dominantDirection: domDir(ds), dominantDirectionCardinal: cardDir(domDir(ds)), windSummary: {speed:0,direction:0,directionCardinal:'N'}, sunrise: wea.daily.sunrise[i], sunset: wea.daily.sunset[i] }; });
  return { current: cur, hourly, daily, metadata: { source: 'Open-Meteo', cachedAt: new Date().toISOString(), confidence: 90, attribution: ['Weather data by Open-Meteo (https://open-meteo.com)', 'Marine data by Open-Meteo Marine API'], latitude: lat, longitude: lon } };
}

export async function searchLocations(query: string) {
  const r = await fetch(`${GEOCODE}?name=${encodeURIComponent(query)}&count=10&language=en&format=json`);
  const d = await r.json();
  return d.results?.map((x:any)=>({ name: `${x.name}${x.admin1?`, ${x.admin1}`:''}${x.country?`, ${x.country}`:''}`, lat: x.latitude, lon: x.longitude, country: x.country||'' }))||[];
}