import type { Spot, Orientation, WaveType } from '@/types';
import type { ScoringInput } from '@/types';
import { scoreConditions } from '@/lib/scoring';

const OVERPASS = 'https://overpass-api.de/api/interpreter';
const QUERY = `[out:json][timeout:25];(way["natural"="coastline"]({{bbox}});way["natural"="beach"]({{bbox}});way["leisure"="beach_resort"]({{bbox}});node["natural"="cape"]({{bbox}});node["natural"="headland"]({{bbox}}));out center geom;`;

interface El { type: 'node'|'way'|'relation'; id: number; lat?: number; lon?: number; center?: {lat:number;lon:number}; geometry?: {lat:number;lon:number}[]; tags?: Record<string,string>; }
interface Res { elements: El[]; }

function bbox(lat: number, lon: number, r: number) { const ld = r/111, ln = r/(111*Math.cos(lat*Math.PI/180)); return {n:lat+ld,s:lat-ld,e:lon+ln,w:lon-ln}; }
function hav(lat1: number, lon1: number, lat2: number, lon2: number) { const R=6371, dLat=(lat2-lat1)*Math.PI/180, dLon=(lon2-lon1)*Math.PI/180, a=Math.sin(dLat/2)**2+Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLon/2)**2; return 2*R*Math.asin(Math.sqrt(a)); }
function bear(lat1: number, lon1: number, lat2: number, lon2: number) { const dLon=(lon2-lon1)*Math.PI/180, la1=lat1*Math.PI/180, la2=lat2*Math.PI/180, y=Math.sin(dLon)*Math.cos(la2), x=Math.cos(la1)*Math.sin(la2)-Math.sin(la1)*Math.cos(la2)*Math.cos(dLon); let b=Math.atan2(y,x)*180/Math.PI; return (b+360)%360; }
function ang2ori(a: number): Orientation { if(a>=337.5||a<22.5) return 'N'; if(a<67.5) return 'NE'; if(a<112.5) return 'E'; if(a<157.5) return 'SE'; if(a<202.5) return 'S'; if(a<247.5) return 'SW'; if(a<292.5) return 'W'; return 'NW'; }
function ori2ang(o: Orientation) { const m={N:0,NE:45,E:90,SE:135,S:180,SW:225,W:270,NW:315}; return m[o]; }
function inferWave(tags?: Record<string,string>): WaveType { if(!tags) return 'unknown'; if(tags.natural==='beach'||tags.leisure==='beach_resort') return 'beach'; if(tags.natural==='cape'||tags.natural==='headland') return 'point'; if(tags.man_made==='breakwater'||tags.man_made==='groyne') return 'reef'; return 'unknown'; }
function spotName(tags: Record<string,string>|undefined, lat: number, lon: number, i: number) { if(tags?.name) return tags.name; if(tags?.['name:en']) return tags['name:en']; const ld=lat>=0?'N':'S', ln=lon>=0?'E':'W'; return `Break ${ld}${Math.abs(lat).toFixed(2)} ${ln}${Math.abs(lon).toFixed(2)} (${i+1})`; }
function drive(km: number) { return Math.max(5, Math.round(km*2.5)); }

export async function fetchCoastlineSpots(lat: number, lon: number, radiusKm=50): Promise<Spot[]> {
  const b = bbox(lat, lon, radiusKm);
  const q = QUERY.replace('{{bbox}}', `${b.s},${b.w},${b.n},${b.e}`);
  try {
    const r = await fetch(OVERPASS, { method: 'POST', headers: {'Content-Type':'application/x-www-form-urlencoded'}, body: `data=${encodeURIComponent(q)}` });
    if(!r.ok) throw new Error('Overpass error');
    const d: Res = await r.json();
    return processData(d.elements, lat, lon, radiusKm);
  } catch { return fallbackSpots(lat, lon, radiusKm); }
}

function processData(els: El[], ulat: number, ulon: number, rad: number): Spot[] {
  const spots: Spot[] = []; const seen = new Set<string>();
  for(const el of els) {
    if(el.type==='way' && el.geometry && el.geometry.length>=2) {
      for(let i=0;i<el.geometry.length-1;i+=Math.max(1,Math.floor(el.geometry.length/10))) {
        const p1=el.geometry[i], p2=el.geometry[Math.min(i+1,el.geometry.length-1)];
        const clat=(p1.lat+p2.lat)/2, clon=(p1.lon+p2.lon)/2;
        const dist=hav(ulat,ulon,clat,clon); if(dist>rad) continue;
        const ang=bear(p1.lat,p1.lon,p2.lat,p2.lon); const ori=ang2ori((ang+90)%360);
        const wt=inferWave(el.tags); const nm=spotName(el.tags,clat,clon,spots.length);
        const key=`${Math.round(clat*1000)},${Math.round(clon*1000)}`; if(seen.has(key)) continue; seen.add(key);
        spots.push({id:`spot-${el.id}-${i}`,name:nm,latitude:clat,longitude:clon,distanceKm:Math.round(dist*10)/10,driveTimeMin:drive(dist),suitabilityScore:0,bestWindow:null,hazards:[],estimated:true,orientation:ori,waveType:wt,coastlineAngle:ori2ang(ori)});
      }
    } else if(el.type==='node' && el.lat && el.lon) {
      const dist=hav(ulat,ulon,el.lat,el.lon); if(dist>rad) continue;
      const ori=el.tags?.facing?.toUpperCase(); const orientation=(['N','NE','E','SE','S','SW','W','NW'].includes(ori||'')?ori:'W') as Orientation;
      const wt=inferWave(el.tags); const nm=el.tags?.name||`Spot near ${el.lat.toFixed(3)}, ${el.lon.toFixed(3)}`;
      const key=`${Math.round(el.lat*1000)},${Math.round(el.lon*1000)}`; if(seen.has(key)) continue; seen.add(key);
      spots.push({id:`spot-${el.id}`,name:nm,latitude:el.lat,longitude:el.lon,distanceKm:Math.round(dist*10)/10,driveTimeMin:drive(dist),suitabilityScore:0,bestWindow:null,hazards:[],estimated:true,orientation,waveType:wt,coastlineAngle:ori2ang(orientation)});
    }
  }
  return spots.slice(0,50);
}

function fallbackSpots(lat: number, lon: number, rad: number): Spot[] {
  const spots: Spot[] = []; const count=Math.min(20,Math.max(5,Math.floor(rad/5)));
  for(let i=0;i<count;i++) { const ang=(i/count)*360; const dist=(Math.random()*0.8+0.2)*rad; const slat=lat+(dist/111)*Math.cos(ang*Math.PI/180); const slon=lon+(dist/(111*Math.cos(lat*Math.PI/180)))*Math.sin(ang*Math.PI/180); const ori=ang2ori((ang+180)%360);
    spots.push({id:`fallback-${i}`,name:`Coastal Break ${i+1}`,latitude:slat,longitude:slon,distanceKm:Math.round(dist*10)/10,driveTimeMin:drive(dist),suitabilityScore:0,bestWindow:null,hazards:[],estimated:true,orientation:ori,waveType:'unknown',coastlineAngle:ori2ang(ori)});
  }
  return spots;
}

export async function rankSpots(spots: Spot[], conditions: ScoringInput[], level: number): Promise<Spot[]> {
  const scored = await Promise.all(spots.map(async s => {
    const rel = conditions.find(c=>{ const diff=Math.abs(((c.waveDirection-s.coastlineAngle+180)%360)-180); return diff<90; })||conditions[0];
    const sc = scoreConditions({...rel, coastlineAngle: s.coastlineAngle}, level);
    return {...s, suitabilityScore: sc.overallScore, bestWindow: sc.bestWindow, hazards: sc.hazards};
  }));
  return scored.sort((a,b)=>b.suitabilityScore-a.suitabilityScore).map((s,i)=>({...s,id:`ranked-${i}-${s.id}`}));
}