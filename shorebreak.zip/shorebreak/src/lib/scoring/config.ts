export const SCORING_CONFIG = {
  swell: { periodWeight: 0.4, heightWeight: 0.3, swellWindRatioWeight: 0.3, directionWeight: 0.0,
    periodScoreMap: [{min:0,max:8,score:0},{min:8,max:10,score:20},{min:10,max:12,score:50},{min:12,max:14,score:75},{min:14,max:16,score:90},{min:16,max:100,score:100}],
    heightScoreMap: [{min:0,max:0.5,score:60},{min:0.5,max:1,score:100},{min:1,max:2,score:90},{min:2,max:3,score:70},{min:3,max:4,score:50},{min:4,max:6,score:30},{min:6,max:8,score:15},{min:8,max:100,score:5}] },
  wind: { offshoreBase: 100, offshoreSpeedPenalty: 2.0, crossShoreBase: 60, crossShoreSpeedPenalty: 1.5, onshoreBase: 20, onshoreSpeedPenalty: 3.0, calmBonus: 10, calmThresholdKnots: 5 },
  beginner: [
    { level: 1, name: 'Foam-board Basics', maxHeightFt: 2, minPeriodSec: 8, maxOnshoreWindKnots: 10, maxCrossWindKnots: 12, tidePreference: 'mid', maxHeightPenalty: 0.4, minPeriodPenalty: 0.3, windPenalty: 0.3 },
    { level: 2, name: 'Whitewater Riding', maxHeightFt: 3, minPeriodSec: 7, maxOnshoreWindKnots: 12, maxCrossWindKnots: 15, tidePreference: 'mid', maxHeightPenalty: 0.35, minPeriodPenalty: 0.25, windPenalty: 0.25 },
    { level: 3, name: 'Green Waves', maxHeightFt: 4, minPeriodSec: 6, maxOnshoreWindKnots: 15, maxCrossWindKnots: 18, tidePreference: 'mid', maxHeightPenalty: 0.3, minPeriodPenalty: 0.2, windPenalty: 0.2 },
    { level: 4, name: 'Lineup Surfing', maxHeightFt: 6, minPeriodSec: 5, maxOnshoreWindKnots: 20, maxCrossWindKnots: 22, tidePreference: 'any', maxHeightPenalty: 0.2, minPeriodPenalty: 0.15, windPenalty: 0.15 },
    { level: 5, name: 'Intermediate', maxHeightFt: 8, minPeriodSec: 4, maxOnshoreWindKnots: 25, maxCrossWindKnots: 28, tidePreference: 'any', maxHeightPenalty: 0.1, minPeriodPenalty: 0.1, windPenalty: 0.1 },
  ],
  hazards: { bigPeriodJump: { periodThresholdSec: 14, heightIncreasePercent: 50, timeWindowHours: 6 }, strongOnshore: { windSpeedKnots: 15 }, ripRisk: { minHeightFt: 4, tideThreshold: 'low', channelWidthHeuristic: 100 }, coldWater: { tempThresholdF: 60, tempThresholdC: 15.5 }, lowDaylight: { hoursBeforeSunset: 2 }, highUV: { uvIndexThreshold: 8 } },
  confidence: { baseConfidence: 95, decayPerDay: 8, minConfidence: 30, providerWeights: { openMeteo: 0.7, noaa: 0.3 } },
};

export function getLevelConfig(level: number) { return SCORING_CONFIG.beginner.find(l => l.level === level) || SCORING_CONFIG.beginner[2]; }
export function getPeriodScore(period: number) { const e = SCORING_CONFIG.swell.periodScoreMap.find(p => period >= p.min && period < p.max); return e?.score || 0; }
export function getHeightScore(heightFt: number) { const e = SCORING_CONFIG.swell.heightScoreMap.find(h => heightFt >= h.min && heightFt < h.max); return e?.score || 0; }