import type { UserProfile, SurfLevel, SkillQuizAnswers, SkillQuizResult, SessionEntry, FavoriteSpot, UnitPreferences, NotificationSettings, PrivacySettings, AgeRange, BoardType } from '@/types';
import { LEVEL_DEFINITIONS } from '@/types';
const K = 'shorebreak_user';
const DEF_SET = { units: { distance: 'km', temperature: 'celsius', windSpeed: 'knots', waveHeight: 'ft' } as UnitPreferences, notifications: { alertsEnabled: false, alertLevel: 3, alertRadiusKm: 50, alertTimeWindow: { start: '06:00', end: '10:00' }, maxWindKnots: 15, pushEnabled: false } as NotificationSettings, privacy: { shareLocation: false, analyticsOptIn: false, dataRetentionDays: 365 } as PrivacySettings };
export function getProfile(): UserProfile|null { if(typeof window==='undefined') return null; try{ return JSON.parse(localStorage.getItem(K)||'null'); }catch{return null} }
export function save(p: UserProfile) { if(typeof window==='undefined') return; localStorage.setItem(K, JSON.stringify(p)); }
export function getOrCreate(): UserProfile { let p=getProfile(); if(!p){ p=createDefault(); save(p);} return p; }
function createDefault(): UserProfile { return { level: 1, weightKg: 75, heightCm: 175, ageRange: '26-35', boardOwned: 'none', favorites: [], checklists: {}, sessionLog: [], settings: DEF_SET }; }
export function setLevel(l: SurfLevel) { const p=getOrCreate(); p.level=l; if(!p.checklists[l]) p.checklists[l]={}; save(p); return p; }
export function addFav(s: FavoriteSpot) { const p=getOrCreate(); if(!p.favorites.find(f=>f.id===s.id)){ p.favorites.push(s); save(p);} return p; }
export function remFav(id: string) { const p=getOrCreate(); p.favorites=p.favorites.filter(f=>f.id!==id); save(p); return p; }
export function setChecklist(level: number, skill: string, v: 'not-yet'|'sometimes'|'consistent') { const p=getOrCreate(); if(!p.checklists[level]) p.checklists[level]={}; p.checklists[level][skill]=v; save(p); return p; }
export function addSession(e: Omit<SessionEntry,'id'>) { const p=getOrCreate(); p.sessionLog.unshift({...e, id:`sess-${Date.now()}-${Math.random().toString(36).slice(2,9)}`}); if(p.sessionLog.length>100) p.sessionLog=p.sessionLog.slice(0,100); save(p); return p; }
export function updSettings(s: Partial<UserProfile['settings']>) { const p=getOrCreate(); p.settings={...p.settings,...s}; save(p); return p; }
export function quizResult(a: SkillQuizAnswers): SkillQuizResult {
  const b = { swim: a.swimComfort*10, exp: Math.min(a.timesSurfed*5,50), tech: a.canPaddleAndPopUp?30:10, comf: a.comfortChestHigh?25:10, know: a.etiquetteKnowledge*10, fit: a.fitnessLevel*10, age: {'under-18':20,'18-25':30,'26-35':25,'36-50':15,'50+':10}[a.ageRange]||20, equip: {foam:20,funboard:15,fish:10,shortboard:5,longboard:15,none:10}[a.boardOwned]||10 };
  const tot = Object.values(b).reduce((a,b)=>a+b,0);
  let lvl: SurfLevel = tot<80?1:tot<120?2:tot<160?3:tot<200?4:5;
  const reasons = [`Score ${tot} → Level ${lvl}: ${LEVEL_DEFINITIONS.find(x=>x.level===lvl)?.name}`];
  if(a.timesSurfed===0) reasons.push('First-time surfer - start with foam board basics');
  else if(a.timesSurfed<5) reasons.push(`Limited experience (${a.timesSurfed} sessions) - focus on fundamentals`);
  if(!a.canPaddleAndPopUp) reasons.push('Need to work on paddle and pop-up technique');
  if(!a.comfortChestHigh) reasons.push('Not yet comfortable in chest-high waves');
  if(a.etiquetteKnowledge<3) reasons.push('Should review surf etiquette and lineup rules');
  return { level: lvl, confidence: Math.min(95,tot), reasoning: reasons, breakdown: b };
}
export function clearData() { if(typeof window==='undefined') return; localStorage.removeItem(K); }