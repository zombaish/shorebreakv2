export function convWave(ft: number, u: 'ft'|'m') { return u==='m'?Math.round(ft*0.3048*10)/10:ft; }
export function convWind(kt: number, u: 'knots'|'mph'|'kph') { if(u==='mph') return Math.round(kt*1.15078); if(u==='kph') return Math.round(kt*1.852); return kt; }
export function convTemp(f: number, u: 'celsius'|'fahrenheit') { return u==='celsius'?Math.round((f-32)*5/9):f; }
export function convDist(km: number, u: 'km'|'mi') { return u==='mi'?Math.round(km*0.621371*10)/10:km; }
export function fmtWave(ft: number, u: 'ft'|'m') { return `${convWave(ft,u)}${u}`; }
export function fmtWind(kt: number, u: 'knots'|'mph'|'kph') { const l={knots:'kt',mph:'mph',kph:'km/h'}; return `${convWind(kt,u)} ${l[u]}`; }
export function fmtTemp(f: number, u: 'celsius'|'fahrenheit') { return `${convTemp(f,u)}°${u==='celsius'?'C':'F'}`; }
export function fmtDist(km: number, u: 'km'|'mi') { return `${convDist(km,u)}${u==='mi'?' mi':' km'}`; }
export function bodyH(ft: number) { if(ft<1) return 'ankle-high'; if(ft<2) return 'knee-high'; if(ft<3) return 'waist-high'; if(ft<4) return 'chest-high'; if(ft<5) return 'head-high'; if(ft<6) return 'overhead'; if(ft<8) return 'double overhead'; return 'triple overhead+'; }
export function windDesc(kt: number, rel: 'offshore'|'onshore'|'cross-shore') { const s=kt<5?'calm':kt<10?'light':kt<15?'moderate':kt<20?'strong':'very strong'; return `${s} ${rel} wind`; }
export function relWind(wind: number, coast: number) { const d=Math.abs((((wind-(coast+180))%360)+360)%360); if(d<=45) return 'offshore'; if(d<=135) return 'cross-shore'; return 'onshore'; }
export function fmtTime(s: string) { return new Date(s).toLocaleTimeString([],{hour:'numeric',minute:'2-digit',hour12:true}); }
export function fmtDate(s: string) { return new Date(s).toLocaleDateString([],{weekday:'short',month:'short',day:'numeric'}); }
export function dayName(s: string) { return new Date(s).toLocaleDateString([],{weekday:'long'}); }
export function hrsToSunset(s: string, now=new Date()) { return (new Date(s).getTime()-now.getTime())/3.6e6; }
export function isDay(rise: string, set: string, now=new Date()) { return now>=new Date(rise) && now<=new Date(set); }