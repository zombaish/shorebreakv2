export interface WaveData {
  height: number; period: number; direction: number; directionCardinal: string;
}
export interface WindData { speed: number; direction: number; directionCardinal: string; gusts?: number; }
export interface TideData { height: number; type: 'high' | 'low' | 'mid'; time: string; }
export interface CurrentConditions {
  wave: WaveData; wind: WindData; waterTemp: number; airTemp: number; tide?: TideData; timestamp: string;
}
export interface HourlyForecast {
  time: string; wave: WaveData; wind: WindData; waterTemp: number; airTemp: number; tideHeight?: number;
  sunrise?: string; sunset?: string; uvIndex?: number;
}
export interface DailyForecast {
  date: string; maxWaveHeight: number; minWaveHeight: number; dominantPeriod: number; dominantDirection: number;
  dominantDirectionCardinal: string; windSummary: WindData; tideHigh?: TideData; tideLow?: TideData;
  sunrise: string; sunset: string;
}
export interface ConditionsResponse {
  current: CurrentConditions; hourly: HourlyForecast[]; daily: DailyForecast[];
  metadata: { source: string; cachedAt: string; confidence: number; attribution: string[]; latitude: number; longitude: number; };
}
export interface ScoreResponse {
  suitability: 'good' | 'okay' | 'skip'; score: number; reasons: string[];
  bestWindow: { start: string; end: string; score: number } | null;
  hazards: HazardFlag[]; confidence: number; level: number;
}
export interface HazardFlag {
  type: 'BIG_PERIOD_JUMP' | 'STRONG_ONSHORE' | 'RIP_RISK' | 'COLD_WATER' | 'LOW_DAYLIGHT' | 'HIGH_UV';
  severity: 'low' | 'medium' | 'high'; message: string;
}
export interface Spot {
  id: string; name: string; latitude: number; longitude: number; distanceKm: number; driveTimeMin: number;
  suitabilityScore: number; bestWindow: { start: string; end: string; score: number } | null;
  hazards: HazardFlag[]; estimated: boolean; orientation: Orientation; waveType: WaveType; coastlineAngle: number;
}
export type Orientation = 'N' | 'NE' | 'E' | 'SE' | 'S' | 'SW' | 'W' | 'NW';
export type WaveType = 'beach' | 'point' | 'reef' | 'unknown';
export interface SpotsResponse { spots: Spot[]; metadata: { cachedAt: string; count: number; searchRadiusKm: number; userLevel: number }; }
export interface ScoringInput {
  waveHeight: number; wavePeriod: number; waveDirection: number; windSpeed: number; windDirection: number;
  waterTemp: number; airTemp: number; tideHeight?: number; tideType?: 'high' | 'low' | 'mid';
  sunrise?: string; sunset?: string; uvIndex?: number; coastlineAngle: number; forecastHoursOut: number;
  swellHeight?: number; windWaveHeight?: number; timestamp?: string;
}
export interface ScoringResult {
  swellQuality: number; windScore: number; tideSuitability: number; beginnerScore: number; overallScore: number;
  suitability: 'good' | 'okay' | 'skip'; reasons: string[];
  bestWindow: { start: string; end: string; score: number } | null; hazards: HazardFlag[]; confidence: number;
}
export type SurfLevel = 1 | 2 | 3 | 4 | 5;
export interface LevelDefinition {
  level: SurfLevel; name: string; description: string; maxWaveHeightFt: number; minPeriodSec: number; maxWindKnots: number;
  skills: string[]; color: string; icon: string;
}
export const LEVEL_DEFINITIONS: LevelDefinition[] = [
  { level: 1, name: 'Foam-board Basics', description: 'Learning to catch whitewater, pop up, and ride straight', maxWaveHeightFt: 2, minPeriodSec: 8, maxWindKnots: 10, skills: ['Safe paddling', 'Pop-up in whitewater', 'Riding straight', 'Board control'], color: 'green', icon: '🏄‍♂️' },
  { level: 2, name: 'Whitewater Riding', description: 'Comfortable in whitewater, learning to turn and control speed', maxWaveHeightFt: 3, minPeriodSec: 7, maxWindKnots: 12, skills: ['Turning in whitewater', 'Speed control', 'Paddling out', 'Wave selection basics'], color: 'lime', icon: '🌊' },
  { level: 3, name: 'Green Waves', description: 'Catching unbroken waves, learning to angle and trim', maxWaveHeightFt: 4, minPeriodSec: 6, maxWindKnots: 15, skills: ['Catching green waves', 'Angling takeoff', 'Trimming', 'Reading sets'], color: 'yellow', icon: '🌊' },
  { level: 4, name: 'Lineup Surfing', description: 'Comfortable in the lineup, duck diving, wave priority', maxWaveHeightFt: 6, minPeriodSec: 5, maxWindKnots: 20, skills: ['Duck diving/turtle roll', 'Lineup etiquette', 'Wave priority', 'Bottom turns'], color: 'orange', icon: '🏄‍♂️' },
  { level: 5, name: 'Intermediate', description: 'Confident in varied conditions, developing maneuvers', maxWaveHeightFt: 8, minPeriodSec: 4, maxWindKnots: 25, skills: ['Cutbacks', 'Floaters', 'Re-entries', 'Barrel basics', 'Competition rules'], color: 'red', icon: '🏆' },
];
export type AgeRange = 'under-18' | '18-25' | '26-35' | '36-50' | '50+';
export type BoardType = 'foam' | 'funboard' | 'fish' | 'shortboard' | 'longboard' | 'none';
export interface UserProfile {
  level: SurfLevel; weightKg: number; heightCm: number; ageRange: AgeRange; boardOwned?: BoardType;
  favorites: FavoriteSpot[]; checklists: ChecklistProgress; sessionLog: SessionEntry[]; settings: UserSettings;
}
export interface FavoriteSpot { id: string; name: string; latitude: number; longitude: number; notes?: string; addedAt: string; }
export interface ChecklistProgress { [level: number]: { [skillId: string]: 'not-yet' | 'sometimes' | 'consistent'; }; }
export interface SessionEntry { id: string; date: string; spotId: string; spotName: string; conditions: SessionConditions; durationMinutes: number; skillsWorkedOn: string[]; rating: 1|2|3|4|5; notes?: string; levelAtTime: SurfLevel; }
export interface SessionConditions { waveHeightFt: number; wavePeriodSec: number; windSpeedKnots: number; windDirection: string; waterTempF: number; tide: 'high' | 'low' | 'mid'; }
export interface UserSettings {
  units: UnitPreferences; notifications: NotificationSettings; privacy: PrivacySettings;
}
export interface UnitPreferences { distance: 'km' | 'mi'; temperature: 'celsius' | 'fahrenheit'; windSpeed: 'knots' | 'mph' | 'kph'; waveHeight: 'ft' | 'm'; }
export interface NotificationSettings { alertsEnabled: boolean; alertLevel: SurfLevel; alertRadiusKm: number; alertTimeWindow: { start: string; end: string }; maxWindKnots: number; email?: string; pushEnabled: boolean; }
export interface PrivacySettings { shareLocation: boolean; analyticsOptIn: boolean; dataRetentionDays: number; }
export interface SkillQuizAnswers { swimComfort: 1|2|3|4|5; timesSurfed: number; canPaddleAndPopUp: boolean; comfortChestHigh: boolean; etiquetteKnowledge: 1|2|3|4|5; fitnessLevel: 1|2|3|4|5; ageRange: AgeRange; boardOwned: BoardType; }
export interface SkillQuizResult { level: SurfLevel; confidence: number; reasoning: string[]; breakdown: Record<string, number>; }
export interface SkillItem { id: string; name: string; description: string; commonMistakes: string[]; drill: string; required: boolean; category: 'paddling' | 'pop-up' | 'riding' | 'turning' | 'safety' | 'etiquette' | 'knowledge'; }
export interface GearResponse { board: BoardRecommendation; wetsuit: WetsuitRecommendation; essentials: EssentialItem[]; checklist: ChecklistItem[]; }
export interface BoardRecommendation { volumeL: number; type: 'foam' | 'funboard' | 'fish' | 'shortboard' | 'longboard'; buyOrRent: 'buy' | 'rent'; reason: string; alternatives: BoardRecommendation[]; }
export interface WetsuitRecommendation { thicknessMm: string; type: 'spring' | 'full' | 'hooded' | 'none'; accessories: string[]; reason: string; }
export interface EssentialItem { item: string; reason: string; budgetOptions: BudgetOption[]; }
export interface BudgetOption { tier: 'budget' | 'mid' | 'premium'; brand: string; model: string; priceRange: string; reason: string; }
export interface ChecklistItem { item: string; packed: boolean; category: 'board' | 'wetsuit' | 'safety' | 'accessory'; }